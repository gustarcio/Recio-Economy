function [luxuryPlan luxuryProducts] = viableExcessConsumption(availableProducts,prices,consumptionPattern,consumables,luxuryExpenses),
	% -- Function file: [luxuryPlan luxuryProducts] = viableExcessConsumption(availableProducts,prices,consumptionPattern,consumables,luxuryExpenses)
	% 
	% Summary: spend luxuryExpenses in buying things that are actually available
	% in the market stock at the current prices following a consumption
	% pattern whenever possible.
	%
	% The function returns the luxury plan stating the amounts of products
	% to be consumed and the actual product indexes.
	
	%work out the unit cost of the given pattern (current prices)
	unitCostOfPattern=prices(consumables)*consumptionPattern';
	%work out how much can be bought with the current budget (luxury expenses)
	luxuryPlan=(luxuryExpenses/unitCostOfPattern)*consumptionPattern;
	%make minor adjustments to plan if not enough products available
	if sum(luxuryPlan>availableProducts(consumables))>0,
		targetProducts=find(luxuryPlan>availableProducts(consumables));
		luxuryPlan(targetProducts)=availableProducts(consumables(targetProducts));
	end
	%specify which products are to be consumed (this could be removed)
	luxuryProducts=consumables;
end