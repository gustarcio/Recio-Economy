function [prices] = workOutPricesRational(availableProducts, minStock, prices),
	% -- Function file: [prices] = workOutPricesRational(availableProducts, minStock, prices)
	%
	% Summary: adjust the prices as a function of the balance between supply and 
	% demand to keep a constant stock for each product proportional to the 
	% number of producers (minStock).
	%
	% Both, supply and demand are accounted for in the available products
	% which have to match the required stock. Changing the prices will have
	% effect in the profits and therefore in the production outcomes of the 
	% producer agents.
	%
	% Prices are adjusted using a sigmoid function to control the rate of change
	% in some proportion to the difference between available products and minimum
	% stock.
	
	%sigmoid function parameters (can be plotted below)
	alphaRational=20;
	magnitudeRational=0.2;
	offsetRational=1.1;
	for counter=1:length(prices),
		%for each product
		if availableProducts(counter)==minStock(counter),
			%do not change prices
			prices(counter)=prices(counter);
		elseif availableProducts(counter)>minStock(counter),
			%decrease the price
			valueAtOne=magnitudeRational*(1./(1+exp(-alphaRational*(1-offsetRational))));
			if minStock(counter),
				% avoid division by zero
				rateOfChange=magnitudeRational*(1./(1+exp(-alphaRational*(availableProducts(counter)/minStock(counter)-offsetRational))))-valueAtOne;
			else
				% by setting rate of change to maximum value
				rateOfChange=magnitudeRational-valueAtOne;
			end
			%actual change of price
			prices(counter)=prices(counter)*(1-rateOfChange);
		else
			%increase the price
			valueAtOne=magnitudeRational*(1./(1+exp(-alphaRational*(1-offsetRational))));
			if availableProducts(counter),
				% avoid division by zero
				rateOfChange=magnitudeRational*(1./(1+exp(-alphaRational*(minStock(counter)/availableProducts(counter)-offsetRational))))-valueAtOne;
			else
				% by setting rate of change to maximum value
				rateOfChange=magnitudeRational-valueAtOne;
			end
			%actual change of price
			prices(counter)=prices(counter)*(1+rateOfChange);
		end
	end%for
	% % the following line calls a function that plots the current sigmoid function used for the price adjustment 
	% plotBehaviours(alphaRational,magnitudeRational,offsetRational)
end %workOutPricesRational()
function [] = plotBehaviours(alphaRational,magnitudeRational,offsetRational),
	xrange=linspace(1,2,100);
	yValues=magnitudeRational*(1./(1+exp(-alphaRational*(xrange-offsetRational))));
	valueAtOne=magnitudeRational*(1./(1+exp(-alphaRational*(1-offsetRational))));
	yValues=magnitudeRational*(1./(1+exp(-alphaRational*(xrange-offsetRational))))-valueAtOne;
	figure(101),plot(xrange,yValues);
	keyboard
end%plotBehaviours()