function [] = storeProducerConsumerBalance(fileName,myRecord),

	csvHeader=['Iteration,Producers,Consumers \n'];
	csvFileID=fopen(fileName,'w');
	fprintf(csvFileID,csvHeader);
	for iterationCounter=1:length(myRecord),
		xRange(iterationCounter)=iterationCounter;
		producers(iterationCounter)=myRecord(iterationCounter).producerConsumerBalance(1);
		consumers(iterationCounter)=myRecord(iterationCounter).producerConsumerBalance(2);
		fprintf(csvFileID,[num2str(iterationCounter) ',' num2str(producers(iterationCounter)) ',' num2str(consumers(iterationCounter)) '\n'])
	end
	fclose(csvFileID);
end%plotResults()