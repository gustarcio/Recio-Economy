function [removalOutcome inputMatrix outputMatrix inputMatrixWaste outputMatrixWaste agents prices manufactured consumables numberOfProducts numberOfTechnologies productVectorIndex producerSkillsRelative producerSkills producerIntroductionMatrix sellingStock targetStock productionBuffer productionStock profitVector profitBuffer meanProfits productNames technologyNames producerConcentrationsBuffer consumptionPatternIndex consumptionWasteGeneration] = removeTechnology(targetTechnology,inputMatrix,outputMatrix,inputMatrixWaste,outputMatrixWaste,agents,prices,manufactured,consumables,producerSkills,productVectorIndex,producerIntroductionMatrix,targetStock,productionBuffer,productionStock,profitVector,profitBuffer,meanProfits,productNames,technologyNames,producerConcentrationsBuffer,sellingStock,consumptionPatternIndex,consumptionWasteGeneration),
	% -- Function file: 
	%	[removalOutcome inputMatrix outputMatrix 
	%	agents prices manufactured consumables 
	%	numberOfProducts numberOfTechnologies productVectorIndex 
	%	producerSkillsRelative producerSkills producerIntroductionMatrix 
	%	sellingStock targetStock productionBuffer 
	%	productionStock profitVector profitBuffer 
	%	meanProfits productNames technologyNames 
	%	producerConcentrationsBuffer consumptionPatternIndex] =
	%		removeTechnology(targetTechnology,inputMatrix,outputMatrix,
	%			agents,prices,manufactured,
	%			consumables,producerSkills,productVectorIndex,
	%			producerIntroductionMatrix,targetStock,productionBuffer,
	%			productionStock,profitVector,profitBuffer,
	%			meanProfits,productNames,technologyNames,
	%			producerConcentrationsBuffer,sellingStock,consumptionPatternIndex)
	%
	% Summary: remove technology indicated by targetTechnology if the production outcome is not being used by
	% others or if there are other producers of the same comodity. If the target technology is the 
	% only one in the market producing a given comodity then remove the product too (from vonNeumann 
	% matrices). Then rearrange all related matrices and vectors.

	removalOutcome=0; %this variable is used to monitor if the technology has been removed or it has other dependencies
	numberOfCoordinates=2;
	numberOfIdentifiers=1;
	agentColumnsToBeRemoved=[]; %point out what columns must be removed (technology products skills etc)
	removeGivenTech=0; %initial check to not remove the technology
	% the following are needed to have a list of return values even if no action is taken
	[numberOfProducts numberOfTechnologies]=size(inputMatrix);
	producerSkillsRelative=(1:numberOfTechnologies);
	%find out the capital and product of the target technology
	outputVector=outputMatrix(:,targetTechnology);
	inputVector=inputMatrix(:,targetTechnology);
	targetOutput=find(outputVector~=0);
	for productCounter=1:length(targetOutput),
		if ~inputVector(targetOutput(productCounter)),
			producedProduct=targetOutput(productCounter);
		else
			capitalProduct=targetOutput(productCounter);
		end
	end
	%check if the target product is being produced by other technologies
	targetProduct=producedProduct;
	targetAsOutput=find(outputMatrix(targetProduct,:)~=0);
	uniqueProductionProcess=1;
	for technologyCounter=1:length(targetAsOutput),
		if targetAsOutput(technologyCounter)~=targetTechnology,
			%find out the capital and product of the target technologies
			outputVector=outputMatrix(:,targetAsOutput(technologyCounter));
			inputVector=inputMatrix(:,targetAsOutput(technologyCounter));
			targetOutput=find(outputVector~=0);
			for productCounter=1:length(targetOutput),
				if ~inputVector(targetOutput(productCounter)),
					%there are others producing the same product
					if targetOutput(productCounter)==targetProduct,
						uniqueProductionProcess=0;
					end
				end
			end
		end
	end

	if ~uniqueProductionProcess,
		removeGivenTech=1;
	end
	%check if the target product is being used by other technologies or by consumers
	targetProduct=producedProduct;
	targetAsInput=find(inputMatrix(targetProduct,:)~=0);
	if isempty(targetAsInput),
		%if not being used then remove
		removeGivenTech=1;
	end
	if (sum(consumables==targetProduct)>0)&&(length(consumables)>1),
		% remove if it is not the only consumable
		removeGivenTech=1;
	end
	if removeGivenTech,
		%remove technology
		inputMatrix(:,targetTechnology)=[];
		outputMatrix(:,targetTechnology)=[];
		inputMatrixWaste(:,targetTechnology)=[];
		outputMatrixWaste(:,targetTechnology)=[];
		%remove skill from agents matrix
		agentColumnsToBeRemoved=[agentColumnsToBeRemoved producerSkills(targetTechnology)];
		%remove row from producerIntroductionMatrix corresponding to technology to be removed
		producerIntroductionMatrix(targetTechnology,:)=[];
		profitVector(targetTechnology)=[];
		profitBuffer(:,targetTechnology)=[];
		meanProfits(targetTechnology)=[];
		technologyNames(targetTechnology,:)=[];
		producerConcentrationsBuffer(:,targetTechnology)=[];
		% if target product is exclusively produced by target technology then remove product too
		if uniqueProductionProcess,
			%remove product
			inputMatrix(targetProduct,:)=[];
			outputMatrix(targetProduct,:)=[];
			inputMatrixWaste(targetProduct,:)=[];
			outputMatrixWaste(targetProduct,:)=[];
			prices(targetProduct)=[];
			if sum(manufactured==targetProduct)~=0,
				manufactured(find(manufactured==targetProduct))=[];
			end
			%remove product from agents matrix
			if sum(consumables==targetProduct),
				%remove from pattern if it is a consumable
				targetProductInPattern=find(consumables==targetProduct);
				agentColumnsToBeRemoved=[agentColumnsToBeRemoved consumptionPatternIndex(targetProductInPattern)];
				consumptionPatternIndex(targetProductInPattern)=[];
				consumables(targetProductInPattern)=[];
				consumptionWasteGeneration(targetProductInPattern)=[];
				consumerAgents=find(sum(agents(:,producerSkills),2)==0)';
				agents(consumerAgents,consumptionPatternIndex)=agents(consumerAgents,consumptionPatternIndex)./(diag(sum(agents(consumerAgents,consumptionPatternIndex),2))*ones(size(agents(consumerAgents,consumptionPatternIndex))));
			end
			%remove from set of products
			agentColumnsToBeRemoved=[agentColumnsToBeRemoved productVectorIndex(targetProduct)];
			productNames(targetProduct,:)=[];
			sellingStock(targetProduct)=[];
			targetStock(targetProduct)=[];
			productionBuffer(:,targetProduct)=[];
			productionStock(targetProduct)=[]; 
			%recompute indexes for manufactured and consumables
			targetForIndexChange=find(manufactured>targetProduct);
			manufactured(targetForIndexChange)=manufactured(targetForIndexChange)-1;
			targetForIndexChange=find(consumables>targetProduct);
			consumables(targetForIndexChange)=consumables(targetForIndexChange)-1;
		end
		%actual removal of agent matrix columns
		agents(:,agentColumnsToBeRemoved)=[];
		%actual removal of producerIntroduction matrix columns
		producerIntroductionMatrix(:,agentColumnsToBeRemoved)=[];
		[numberOfProducts numberOfTechnologies]=size(inputMatrix);
		productVectorIndex=numberOfCoordinates+numberOfIdentifiers+1:numberOfCoordinates+numberOfIdentifiers+numberOfProducts;
		producerSkillsRelative=(1:numberOfTechnologies); %relative to the skill vector 1st to 4th
		producerSkills=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+producerSkillsRelative;
		numberOfConsumables=length(consumables);
		consumptionPatternRelative=1:numberOfConsumables;
		consumptionPatternIndex=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+numberOfTechnologies+consumptionPatternRelative;
		removalOutcome=1;
	end%remove technology (and product if needed)
end%removeTechnology()