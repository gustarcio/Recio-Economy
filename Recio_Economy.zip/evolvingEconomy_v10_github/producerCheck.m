function isProducer = producerCheck(activeAgent,productionColumnns),
	% -- Function file: isProducer = producerCheck(activeAgent,productionColumnns)
	%
	% Summary: return one if any of the agent's producer skills (productionColumns) are non zero
	
	isProducer=(sum(activeAgent(productionColumnns))>0);
end % consumerCheck()
