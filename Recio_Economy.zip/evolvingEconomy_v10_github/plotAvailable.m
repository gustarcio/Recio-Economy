function [] = plotAvailable(HF,myRecord,varargin),
	% -- Function file: plotPrices(HF,myRecord,varargin)
	%
	% Summary: plot a figure with handle HF with the stored
	% data in the field prices of the struc 
	% myRecord matching the names in varargin
	%
	% example: plotPrices(102,myRecords,'P1','P2')
	
	% check for cell input in function heading
	if iscell(varargin{1}),
		varargin=varargin{1}; %modify varargin accordingly
	end	
	
	figure(HF)
	clf(HF)
	% find out the number of plots
	numberOfPlots=length(varargin);
	% create a platette of colours
	palette = jet(numberOfPlots);
	% for every plot to be done (varargin)
	for plotCounter=1:numberOfPlots,
		%find out the iterations at which such name
		%existed in the system and its value
		xRange=[]; %actual iterations
		toPlot=[]; %actual values
		storingCounter=1; %accounts for the existence of a given technology (in iterations)
		for iterationCounter=1:length(myRecord),
			% fill with characteres (default is blank) if different sizes
			% just for comparison purposes
			products=myRecord(iterationCounter).productNames;  %take the actual names
			targetNamesMatrix=[products;varargin{plotCounter}]; %auto-fill matrix (compared against varargin name)
			targetName=targetNamesMatrix(length(targetNamesMatrix),:);%get the name to be compared with the rigth size (character filled matrix)
			for productCounter=1:length(products),
				%actual comparison
				if sum(targetNamesMatrix(productCounter,:)==targetName)==length(targetNamesMatrix(productCounter,:)),
					%then store in the variables to plot
					availableProducts=myRecord(iterationCounter).availableProducts;
					toPlot(storingCounter)=availableProducts(productCounter);
					xRange(storingCounter)=iterationCounter;
					storingCounter=storingCounter+1;
				end
			end
		end
		%plot figure and set labels
		hold on
		plot(xRange,toPlot,'-','linewidth',2);
		h=get(gca,'children')';
		set(h(1),'color',palette(plotCounter,:));
		hold off		
	end
	legend(varargin,'location','eastoutside')
	xlabel('Iterations')
	ylabel('Available Products')
end%plotResults()