function [] = printMatrices (logFileName,inputMatrix,outputMatrix,manufactured,consumables,productNames,technologyNames),
	logFileID=fopen(logFileName,'a');
	fprintf(logFileID,'\t Input Matrix:\n');
	[rows columns]=size(inputMatrix);
	for counter=1:rows,
		fprintf(logFileID, '\t\t%f ', inputMatrix(counter,:));
		fprintf(logFileID, '\n');
	end
	fprintf(logFileID,'\t Output Matrix:\n');
	for counter=1:rows,
		fprintf(logFileID, '\t\t%f ', outputMatrix(counter,:));
		fprintf(logFileID, '\n');
	end
	% fprintf(logFileID,'\t Manufactured products: %s\n',mat2str(manufactured));
	% fprintf(logFileID,'\t Consumable products: %s\n',mat2str(consumables));


	fprintf(logFileID,'\t Manufactured products by their name: [');
	for prodCounter=1:length(manufactured),
		% fprintf(logFileID,' %d',manufactured(prodCounter));
		fprintf(logFileID,' %s (',productNames(manufactured(prodCounter),:));
		involvedTechs=find(outputMatrix(manufactured(prodCounter),:)==1);
		% fprintf(logFileID,' (T: %s)',mat2str(involvedTechs));
		for techCounter=1:length(involvedTechs),
			fprintf(logFileID,' %s', technologyNames(involvedTechs(techCounter),:));
		end
		fprintf(logFileID,') ')
	end
	fprintf(logFileID,' ]\n')
	fprintf(logFileID,'\t Matrix indexes for manufactured: [')
	for prodCounter=1:length(manufactured),
		fprintf(logFileID,' %d',manufactured(prodCounter));
		involvedTechs=find(outputMatrix(manufactured(prodCounter),:)==1);
	   fprintf(logFileID,' (%s)',mat2str(involvedTechs));
	end
	fprintf(logFileID,' ]\n')




	fprintf(logFileID,'\t Consumable products by their name: [');
	for prodCounter=1:length(consumables),
		fprintf(logFileID,' %s (',productNames(consumables(prodCounter),:));
		involvedTechs=find(outputMatrix(consumables(prodCounter),:)==1);
		for techCounter=1:length(involvedTechs),
			fprintf(logFileID,' %s', technologyNames(involvedTechs(techCounter),:));
		end
		fprintf(logFileID,') ')
	end
	fprintf(logFileID,' ]\n')
	fprintf(logFileID,'\t Matrix indexes for consumables: [')
	for prodCounter=1:length(consumables),
		fprintf(logFileID,' %d',consumables(prodCounter));
		involvedTechs=find(outputMatrix(consumables(prodCounter),:)==1);
	   fprintf(logFileID,' (%s)',mat2str(involvedTechs));
	end
	fprintf(logFileID,' ]\n')

	fclose(logFileID);
end%printMatrices 





