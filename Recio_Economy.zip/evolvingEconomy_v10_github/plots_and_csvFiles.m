load rawOutputProfits.csv
load rawOutputPrices.csv
load rawOutputAvailable.csv
load rawOutputConcentrations.csv

figure(1),
subplot(2,2,1),plot(outputProfits(:,2:149)),title('Profits')
subplot(2,2,2),plot(outputPrices(:,2:102)),title('Prices')
subplot(2,2,3),plot(outputConcentrations(:,2:149)),title('Concentrations')
subplot(2,2,4),plot(outputAvailable(:,2:102)),title('Available')

figure(2),
subplot(1,2,1),plot(outputProfits(1:1000,2:149)),title('Profits')
subplot(1,2,2),plot(outputPrices(1:1000,2:102)),title('Prices')

figure(3),
subplot(1,2,1),plot((1000:2000),outputProfits(1000:2000,2:149)),title('Profits')
subplot(1,2,2),plot((1000:2000),outputPrices(1000:2000,2:102)),title('Prices')

figure(4),
subplot(1,2,1),plot((2000:5000),outputProfits(2000:5000,2:149)),title('Profits')
subplot(1,2,2),plot((2000:5000),outputPrices(2000:5000,2:102)),title('Prices')

load('simulationData001.data','products2Plot','technologies2Plot')

csvHeader='Iteration';
for counter=1:length(technologies2Plot),
	csvHeader=[csvHeader ',' technologies2Plot{counter}];
end
csvHeader=[csvHeader '\n'];

% write the file header and contents
csvFileID=fopen('outputProfits.csv','w');
fprintf(csvFileID,csvHeader);
dlmwrite(csvFileID,rawOutputProfits,'-append');
fclose(csvFileID);

% write the file header and contents
csvFileID=fopen('outputConcentrations.csv','w');
fprintf(csvFileID,csvHeader);
dlmwrite(csvFileID,rawOutputConcentrations,'-append');
fclose(csvFileID);


csvHeader='Iteration';
for counter=1:length(products2Plot),
	csvHeader=[csvHeader ',' products2Plot{counter}];
end
csvHeader=[csvHeader '\n'];

% write the file header and contents
csvFileID=fopen('outputPrices.csv','w');
fprintf(csvFileID,csvHeader);
dlmwrite(csvFileID,rawOutputPrices,'-append');
fclose(csvFileID);

% write the file header and contents
csvFileID=fopen('outputAvailable.csv','w');
fprintf(csvFileID,csvHeader);
dlmwrite(csvFileID,rawOutputAvailable,'-append');
fclose(csvFileID);
