function [agents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock newAgentsProductionBuffer] = introduceNewAgent(agentType,introductionMatrix,agentGlobalCounter,agents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer),
	% -- Function file: [agents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock newAgentsProductionBuffer] =
	%	introduceNewAgent(agentType,introductionMatrix,agentGlobalCounter,agents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer)
	%
	% Summary: create a new agent using the template introductionMatrix
	% and specify the type of agent through agentType
	% 	1<=agentType<=rows(introductionMatrix)
	% then update the sizes of all related matrices and vectors
	% agentGlobalCounter is used to specify the agent's ID
	% agent's location is choosen at random

	numberOfNewAgents=length(agentType); % allows the introduction of several agents per invocation (not being used)
	[numberOfAgents columnOfAgentsMatrix]=size(agents);
	%choose the template for the new agent
	newAgent=introductionMatrix(agentType,:);
	%set the location (warning: this should change if three coordinates are to be used)
	newAgent(1:numberOfNewAgents,1:2)=randi(100,numberOfNewAgents,2);
	%set an ID
	agentGlobalCounter=agentGlobalCounter+numberOfNewAgents;
	newAgent(:,2+1)=(agentGlobalCounter-numberOfNewAgents+1:agentGlobalCounter);
	%include new agent in the agents matrix
	agents(numberOfAgents+1:numberOfAgents+numberOfNewAgents,:)=newAgent;
	%recompute the related parameters
	[numberOfAgents columnOfAgentsMatrix]=size(agents);
	producerAgents=find(sum(agents(:,producerSkills),2)>0)';
	consumerAgents=find(sum(agents(:,producerSkills),2)==0)';
	targetStock=targetStock+newAgent(productVectorIndex);
	newAgentsProductionBuffer=ones(numberOfAgents,length(agentsProductionBuffer(1,:)));
	newAgentsProductionBuffer(1:numberOfAgents-numberOfNewAgents,:)=agentsProductionBuffer;
end%introduceNewAgent()