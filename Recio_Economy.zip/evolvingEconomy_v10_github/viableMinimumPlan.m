function [consumptionPattern consumables] = viableMinimumPlan(activeIndex,agents,prices,consumables,consumptionPatternIndex,inputMatrix,outputMatrix,productVectorIndex,producerSkills),
	% -- Function file: [consumptionPattern consumables] =
	%	viableMinimumPlan(activeIndex,agents,prices,consumables,consumptionPatternIndex,inputMatrix,outputMatrix,productVectorIndex,producerSkills)
	% 
	% Summary: work out a viable minimum consumption plan for survival, i.e. consuming a minimum amount
	% with the current market stock and a given consumption pattern. This consumption pattern
	% must be changed if there are not enough stock, then, the weights (share in consumption 
	% pattern) of the remaining consumables have to be adjusted to satisfy a minimun consumption.
	% 
	% The function returns the normalised value of the consumption pattern and the products to be consumed

	%set up the minimum consumption (this should be a parameter in the function's head!)
	minConsumption=0.15;

	%extract the active agent from agents matrix
	activeAgent=agents(activeIndex,:);
	%work out the selling stock (products available for sale)
	[sellingStock capitalStock availableProducts]=workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills);
	%set up the initial consumption pattern
	consumptionPattern=activeAgent(consumptionPatternIndex);
	%compute survival consumption (consumptionPattern is normalised)
	agentSurvivalConsumption=consumptionPattern*minConsumption;
	%control variable to come out of the next while loop
	completed=0;
	%adjust pattern to satisfy minimum consumption (survival)
	while ~completed
		if ~isempty(consumptionPattern),
			if (sum(sellingStock(consumables)<(agentSurvivalConsumption))>0),
				%make changes to consumption pattern if less stock than minimal consumption
				%find out consumables in short supply
				shortagedConsumables=find(sellingStock(consumables)<(agentSurvivalConsumption));
				%remove them from the pattern
				consumables(shortagedConsumables)=[];
				consumptionPattern(shortagedConsumables)=[];
				consumptionPattern=consumptionPattern/sum(consumptionPattern);
				%recompute survival consumption
				agentSurvivalConsumption=consumptionPattern*minConsumption;
			else
				%come out of the loop (enough stock)
				completed=1;
			end
		else
			%there is no possible consumption (let's hope this doesn't happen!)
			completed=1;
		end
	end
end