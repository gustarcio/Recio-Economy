function [poolOfProducers] = findProducers(agents,targetProduct,inputMatrix,outputMatrix)
	% -- Function file: [poolOfProducers] = findProducers(agents,targetProduct,inputMatrix,outputMatrix)
	%
	% Summary: return a list of index representing the location within 
	% the agents matrix of producers of the target product.
	% A producer using the target product as capital is not 
	% actually producing it but using it.
	% If there are no agents producing the target product it 
	% returns an empty list.

	[numberOfProducts numberOfTechnologies]=size(outputMatrix);
	% find out what products are being produced 
	% and which ones are being used as capital
	nonZeroOutput=find(outputMatrix~=0);
	nonCapitalOutput=nonZeroOutput(find(inputMatrix(nonZeroOutput)==0));
	capitalCells=nonZeroOutput(find(inputMatrix(nonZeroOutput)~=0));
	% create a matrix with production outcome as ones
	productionMatrix=zeros(numberOfProducts,numberOfTechnologies);
	productionMatrix(nonCapitalOutput)=1;
	% identify the technologies that are producing the target product
	targetTechnologies=find(productionMatrix(targetProduct,:)==1);
	% identify what agents have the skill/technology related to target 
	% product and return
	poolOfProducers=find(sum(agents(:,targetTechnologies)==1,2)>0);
end%findSellers()