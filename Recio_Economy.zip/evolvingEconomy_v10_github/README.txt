Improvements of this version:

Update Apr 9, 2020 for version 10

I have modified the main file to stop the consumption for a number of iterations. Please find attached the modified file and include it on you working directory.

I have included a new variable on line 226 to set up the period for the intervention (iteration at which the intervention starts and finishes, 25 to 50 for this simple example consisting on 100 iterations).

Then at line 320 there is an if sentence that prevents them making any consumption if the current iteration is within the above range.





There was a bug in the file introduceNewTechnologies.m, when normalising the input/output coefficients of new 
technologies the multiplying factor targetProfit should be outside a parenthesis to avoid negative values (lines 105-108).

There is a new file resumeExecution to continue a previously saved run for a number of iterations.

Multiple agent removals are allowed.
