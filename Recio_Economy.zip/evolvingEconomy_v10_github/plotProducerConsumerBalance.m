function [] = plotProducerConsumerBalance(HF,myRecord),
	% -- Function file: plotProducerConsumerBalance(HF,myRecord)
	%
	% Summary: plot a figure with handle HF with the stored
	% data in the field producerConsumerBalance of the struc 
	% myRecord (compare global number of producers and consumers)
	%
	% example: plotProducerConsumerBalance(105,myRecords)
	
	figure(HF)
	clf(HF)

	for iterationCounter=1:length(myRecord),
		xRange(iterationCounter)=iterationCounter;
		producers(iterationCounter)=myRecord(iterationCounter).producerConsumerBalance(1);
		consumers(iterationCounter)=myRecord(iterationCounter).producerConsumerBalance(2);
	end
	%plot figure and set labels
	hold on
	plot(xRange,producers,'-k','linewidth',2);
	plot(xRange,consumers,'-b','linewidth',2);
	hold off		
	legend('Producers','Consumers','location','eastoutside')
	xlabel('Iterations')
	ylabel('Global number of producers and consumers')
end%plotResults()