function [productionPlan] = variableProductionPlan(activeAgentIndex,agents,producerSkills,productVectorIndex,inputMatrix,outputMatrix,moneyIndex,prices),
	% -- Function file: [productionPlan] = 
	%	variableProductionPlan(activeAgentIndex,agents,producerSkills,productVectorIndex,inputMatrix,outputMatrix,moneyIndex,prices)
	% 
	% Summary: the production plan of a given agent is limited by three factors:
	% agent's money budget, available stock market and the expected
	% production given by a sigmoid function (profit driven).
	% This function works out those three limiting factors and creates
	% a feasible production plan.

	%initialise production plan
	productionPlan=zeros(1,length(producerSkills));
	%obtain active agent and its posessions
	activeAgent=agents(activeAgentIndex,:);
	posessions=activeAgent(productVectorIndex);
	%find out target technology (agent's production)
	targetTechnology=find(activeAgent(producerSkills)==1);
	%get production vector from vonNeumann matrices
	inputVector=inputMatrix(:,targetTechnology);
	outputVector=outputMatrix(:,targetTechnology);
	%identify capital and production in production vectors
	targetProducts=find(outputVector>0);
	productionOutput=[];
	capitalProduct=[];
	for productCounter=1:length(targetProducts),
		if inputVector(targetProducts(productCounter))==0,
			productionOutput=targetProducts(productCounter);
		else
			capitalProduct=targetProducts(productCounter);
		end
	end
	%work out the maximum production limited by agent's money
	%obtain budget
	agentsMoney=activeAgent(moneyIndex);
	if isempty(capitalProduct),
		%there are not capital products involved in production
		%work out cost of unit production
		unitarianProductionCost=prices*inputVector;
		%work out how much can be produce with current budget
		maxProductionA=agentsMoney/unitarianProductionCost;
	else
		%there are capital products involved in production
		agentsCapital=posessions(capitalProduct);
		%separate the production by the need of acquiring more capital
		inputVectorNoCapital=inputVector;
		inputVectorNoCapital(capitalProduct)=0;
		capitalForUnitarianProduction=inputVector(capitalProduct);
		%how much can be produced without getting more capital
		maxProductionNoMoreCapital=agentsCapital/capitalForUnitarianProduction;
		%and its cost
		maxProductionNoMoreCapitalCost=prices*inputVectorNoCapital*maxProductionNoMoreCapital;
		if maxProductionNoMoreCapitalCost>agentsMoney,
			%above production is limited by the agent's money
			%work out cost of unit production (without more capital)
			unitarianProductionCost=prices*inputVectorNoCapital;
			%work out how much can be produced with current budget
			maxProductionA=agentsMoney/unitarianProductionCost;
		else
			%the agent can increase its production by buying more capital product
			%work out how much money can be spent in buying more capital
			remainingMoney=agentsMoney-maxProductionNoMoreCapitalCost;
			%work out cost of unit production (acquiring new capital)
			unitarianProductionCost=prices*inputVector;
			%work out how much can be produced with the new capital
			maxProductionWithMoreCapital=remainingMoney/unitarianProductionCost;
			%sum production with new capital and without it
			maxProductionA=maxProductionNoMoreCapital+maxProductionWithMoreCapital;
			%the above constitutes the firts limiting factor to the production plan
		end
	end	
	%work out the maximum production limited by available products in the market
	%work out the market stock
	[sellingStock capitalStock availableProducts]=workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills);
	%separate the cases where capital products are needed in production
	if isempty(capitalProduct),
		% no capital product is required
		% find out the production outcome product
		targetProducts=find(inputVector>0);
		% work out how much can be produced by input available in market
		upperProductionByProduct=sellingStock(targetProducts)./inputVector(targetProducts)';
		% constrain agent's production to minimum production by input in market
		maxProductionB=min(upperProductionByProduct);
		%the above constitutes the second limiting factor to the production plan
	else
		% capital product is required in production
		agentsCapital=posessions(capitalProduct);
		%increase the limiting available stock with agent's capital
		sellingStock(capitalProduct)=sellingStock(capitalProduct)+agentsCapital;
		% find out the production outcome product
		targetProducts=find(inputVector>0);
		% work out how much can be produced by input available in market
		upperProductionByProduct=sellingStock(targetProducts)./inputVector(targetProducts)';
		% constrain agent's production to minimum production by input in market
		maxProductionB=min(upperProductionByProduct);
		%the above constitutes the second limiting factor to the production plan
	end
	%expected production given by the sigmoid function (profit driven)
	%work out profits (rational)
	profitVector=prices*outputMatrix./(prices*inputMatrix);
	%call the sigmoid function
	productionPlan=workOutProductionPlan(activeAgent,profitVector,producerSkills);
	%set limiting production as outcome of the expected production by technology profit
	maxProductionC=productionPlan(targetTechnology);
	%the above constitutes the third limiting factor to the production plan
	%the return value will be the minimum of them three production limits
	maxProduction=min([maxProductionA maxProductionB maxProductionC]);
	%return production plan (filled with zeros)
	productionPlan(targetTechnology)=maxProduction;
end