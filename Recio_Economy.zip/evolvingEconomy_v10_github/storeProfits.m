function [] = storeProfits(fileName,myRecord,varargin),
	% -- Function file: storeProfits(fileName,myRecord,varargin)
	%
	% Summary: save the profits data from myRecord
	% into the file given by fileName in csv format 
	% with the corresponding heading
	%
	% example: storeProfits('csvFile.csv',myRecord,'T3','T5');
	
	% check for cell input in function heading
	if iscell(varargin{1}),
		varargin=varargin{1}; %modify varargin accordingly
	end	
	
	% create the header of the csv file
	csvHeader='Iteration';
	
	% find out the number of plots
	numberOfPlots=length(varargin);
	% add iterations column into the variable to save
	myData(:,1)=1:length(myRecord);
	% for every plot to be done (varargin)
	for plotCounter=1:numberOfPlots,
		% set variable to zero to include name in header
		inHeader=0;
		%find out the iterations at which such name
		%existed in the system and its value
		xRange=[]; %actual iterations
		toPlot=[]; %actual values
		storingCounter=1; %accounts for the existence of a given technology (in iterations)
		for iterationCounter=1:length(myRecord),
			% fill with characteres (default is blank) if different sizes
			% just for comparison purposes
			technologies=myRecord(iterationCounter).technologyNames; %take the actual names
			targetNamesMatrix=[technologies;varargin{plotCounter}]; %auto-fill matrix (compared against varargin name)
			targetName=targetNamesMatrix(length(targetNamesMatrix),:); %get the name to be compared with the rigth size (character filled matrix)
			for techCounter=1:length(technologies),
				%actual comparison
				if sum(targetNamesMatrix(techCounter,:)==targetName)==length(targetNamesMatrix(techCounter,:)),
					%then store in the variables to plot
					profitVector=myRecord(iterationCounter).profitVector;
					toPlot(storingCounter)=profitVector(techCounter);
					xRange(storingCounter)=iterationCounter;
					storingCounter=storingCounter+1;
					if ~inHeader,
						csvHeader=[csvHeader ',' varargin{plotCounter}];
						inHeader=1;
					end
					myData(1:length(myRecord),plotCounter+1)=nan;
					myData(xRange,plotCounter+1)=toPlot;
				end
			end
		end
	end
	csvHeader=[csvHeader '\n'];
	% write the file header and contents
	csvFileID=fopen(fileName,'w');
	fprintf(csvFileID,csvHeader);
	dlmwrite(csvFileID,myData,'-append');
	fclose(csvFileID);
end%plotResults()