function [inputMatrix outputMatrix inputMatrixWaste outputMatrixWaste newAgents prices manufactured consumables numberOfProducts numberOfTechnologies productVectorIndex producerSkillsRelative producerSkills numberOfAgents newProducerIntroductionMatrix availableProducts targetStock productionBuffer productionStock profitVector profitBuffer meanProfits productNameCounter technologyNameCounter productNames technologyNames newProducerConcentrationsBuffer consumptionPatternRelativeIndex consumptionPatternIndex agentsProductionBuffer consumptionWasteGeneration]=introduceNewConsumable(inputMatrix,outputMatrix,inputMatrixWaste,outputMatrixWaste,prices,manufactured,consumables,agents,producerIntroductionMatrix,targetStock,productionBuffer,profitBuffer,agentGlobalCounter,agentsProductionBuffer,productNameCounter,technologyNameCounter,productNames,technologyNames,producerConcentrationsBuffer,consumptionWasteGeneration),
	% -- Function file: 
	%	[inputMatrix outputMatrix newAgents 
	%	prices manufactured consumables 
	%	numberOfProducts numberOfTechnologies productVectorIndex
	%	producerSkillsRelative producerSkills numberOfAgents
	%	newProducerIntroductionMatrix availableProducts targetStock
	%	productionBuffer productionStock profitVector
	%	profitBuffer meanProfits productNameCounter
	%	technologyNameCounter productNames technologyNames
	%	newProducerConcentrationsBuffer consumptionPatternRelativeIndex consumptionPatternIndex
	%	agentsProductionBuffer]=
	%		introduceNewConsumable(inputMatrix,outputMatrix,prices, ...
	%			manufactured,consumables,agents, ...
	%			producerIntroductionMatrix,targetStock,productionBuffer, ...
	%			profitBuffer,agentGlobalCounter,agentsProductionBuffer, ...
	%			productNameCounter,technologyNameCounter,productNames, ...
	%			technologyNames,producerConcentrationsBuffer)
	%		
	% Summary: create a new consumable product and it producing technology using capital products and 
	% certain amount for depreciation of capital. There will not be any initial profit for this
	% new technology cost of input equals cost of output. Modify the consumption pattern of all
	% consumer agents to include a certain amount of the new consumable. Then update all related 
	% system variables.
	
	numberOfCoordinates=2;
	numberOfIdentifiers=1;
	
	[numberOfProducts numberOfTechnologies]=size(inputMatrix);
	depreciationOfCapital=0.1; % 10 percent
	% changes turn out into a new product and a new technologies
	numberOfProducts=numberOfProducts+1;
	inputMatrix(numberOfProducts,:)=zeros(1,numberOfTechnologies);
	outputMatrix(numberOfProducts,:)=zeros(1,numberOfTechnologies);
	%select target production for new technology
	targetProductT1=numberOfProducts;
	%choose a capital good for both technologies (avoid choosing target product)
	poolOfProducts=manufactured;
	capitalGoodT1=poolOfProducts(randi(length(poolOfProducts)));
	%create technology vectors
	inputVectorT1=randi(2,numberOfProducts,1)-1;
	inputVectorT1(targetProductT1)=0;%do not use target product of T1 as input
	inputVectorT1(capitalGoodT1)=1;
	inputVectorT1(1)=1;%labour
	inputVectorT1(2)=0;%money
	inputVectorT1(3)=0;%waste
	compoundProducts=find(inputVectorT1~=0);
	inputVectorT1(compoundProducts)=rand(length(compoundProducts),1);
	outputVectorT1=zeros(numberOfProducts,1);
	outputVectorT1(targetProductT1)=1;
	outputVectorT1(capitalGoodT1)=inputVectorT1(capitalGoodT1)*(1-depreciationOfCapital);






	%work out the price from a normal distribution
	meanPrices=mean(prices);
	stdPrices=std(prices);
	prices(numberOfProducts)=0;
	price_bounded=abs(meanPrices+stdPrices*randn(1)); %bound the price of the new product with a normal distribution
	% price_bounded=abs(meanPrices+0.1*stdPrices*randn(1)); %bound the price of the new product with a normal distribution and 10% of the std
	% price_bounded=10*rand(1); %bound the price of the new product in the [0 10] range
	prices(numberOfProducts)=price_bounded;

	%work out what the production should be with the bounded price
	newOutProduction=(prices*inputVectorT1-prices(capitalGoodT1)*outputVectorT1(capitalGoodT1))/prices(targetProductT1);
	outputVectorT1(targetProductT1)=newOutProduction;

	%normalise vectors
	outputVectorT1=outputVectorT1/newOutProduction;
	inputVectorT1=inputVectorT1/newOutProduction;








	% %update the price of the new product
	% prices(numberOfProducts)=0;
	% prices(numberOfProducts)=prices*inputVectorT1-prices(capitalGoodT1)*outputVectorT1(capitalGoodT1); % 0 percent rate of return
	% % prices(numberOfProducts)=prices*inputVectorT1; % 0 percent rate of return

	% meanPrices=mean(prices);
	% stdPrices=std(prices);
	% prices(numberOfProducts)=0;
	% price_bounded=abs(meanPrices+stdPrices*randn(1)); %bound the price of the new product with a normal distribution
	% price_unbounded=prices*inputVectorT1-prices(capitalGoodT1)*outputVectorT1(capitalGoodT1); % 0 percent rate of return
	% scaleFactor=price_unbounded/price_bounded;
	% inputVectorT1=inputVectorT1/scaleFactor;
	% ouputVectorT1=outputVectorT1/scaleFactor;
	% prices(numberOfProducts)=price_bounded;
	
	inputMatrix(:,numberOfTechnologies+1)=inputVectorT1;
	outputMatrix(:,numberOfTechnologies+1)=outputVectorT1;
	
	%allow new product to be choosen as a consumable
	consumables=[consumables targetProductT1];
	numberOfConsumables=length(consumables);
	
	%update all related variables
	[numberOfProducts numberOfTechnologies]=size(inputMatrix);
	productVectorIndex=numberOfCoordinates+numberOfIdentifiers+1:numberOfCoordinates+numberOfIdentifiers+numberOfProducts;
	producerSkillsRelative=(1:numberOfTechnologies); %relative to the skill vector 1st to 4th
	producerSkills=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+producerSkillsRelative;

	consumptionPatternRelativeIndex=1:numberOfConsumables;
	consumptionPatternIndex=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+numberOfTechnologies+consumptionPatternRelativeIndex;
	
	[numberOfAgents agentsColumns]=size(agents);
	agentsColumns=agentsColumns+3; %one new product plus one new technology plus one column in the consumption pattern
	newAgents=zeros(numberOfAgents,agentsColumns);
	newAgents(:,1:productVectorIndex(length(productVectorIndex)-1))=agents(:,1:productVectorIndex(length(productVectorIndex)-1));
	newAgents(:,producerSkills(1):producerSkills(length(producerSkills)-1))=agents(:,producerSkills(1)-1:producerSkills(length(producerSkills)-2));
				
	consumerAgents=find(sum(agents(:,producerSkills(1:length(producerSkills)-1)-1),2)==0)';
	consumptionPattern=zeros(numberOfAgents,numberOfConsumables);

	newPattern=rand(length(consumerAgents),1)*(1+0.5)/numberOfConsumables;
	existingPattern=agents(consumerAgents,consumptionPatternIndex(1)-2:consumptionPatternIndex(length(consumptionPatternIndex)-1)-2);
	
	consumptionPattern(consumerAgents,numberOfConsumables)=newPattern;
	consumptionPattern(consumerAgents,1:numberOfConsumables-1)=existingPattern.*(diag(1-newPattern)*ones(size(existingPattern)));
	
	newAgents(:,consumptionPatternIndex)=consumptionPattern;

	newProducerIntroductionMatrix=zeros(numberOfTechnologies,agentsColumns);

	newProducerIntroductionMatrix(1:numberOfTechnologies-1,1:productVectorIndex(length(productVectorIndex)-1))=producerIntroductionMatrix(:,1:productVectorIndex(length(productVectorIndex)-1));
	newProducerIntroductionMatrix(1:numberOfTechnologies-1,producerSkills(1):producerSkills(length(producerSkills)-1))=producerIntroductionMatrix(:,producerSkills(1)-1:producerSkills(length(producerSkills)-2));

	newProducerIntroductionMatrix(numberOfTechnologies,producerSkills(length(producerSkills)))=1;

	moneyIndex=productVectorIndex(2);
	freeGoodIndex=find(producerIntroductionMatrix(1,:)==inf);
	initialMoney=producerIntroductionMatrix(1,moneyIndex);
	initialStock=10;

	newProducerIntroductionMatrix(numberOfTechnologies,productVectorIndex(targetProductT1))=initialStock;
	newProducerIntroductionMatrix(numberOfTechnologies,moneyIndex)=initialMoney;
	newProducerIntroductionMatrix(numberOfTechnologies,freeGoodIndex)=inf;

	% update the size for all related system variables
	availableProducts=sum(newAgents(:,productVectorIndex));
	targetStock(targetProductT1)=0;
	productionBuffer(:,targetProductT1)=zeros(length(productionBuffer(:,1)),1);
	productionStock=mean(productionBuffer,1);
	
	profitVector=(prices*outputMatrix)./(prices*inputMatrix);
	profitBuffer(:,numberOfTechnologies)=profitVector(numberOfTechnologies)*zeros(length(profitBuffer(:,1)),1);
	meanProfits=mean(profitBuffer,1);

	% introduce a new agent actually implementing the new technology
	agentType=numberOfTechnologies;
	[newAgents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock agentsProductionBuffer] = introduceNewAgent(agentType,newProducerIntroductionMatrix,agentGlobalCounter,newAgents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer);

	productNameCounter=productNameCounter+1;
	newProductName=['P' num2str(productNameCounter)];
	productNames=[productNames;newProductName];
	
	technologyT1Name=['T' num2str(technologyNameCounter+1)];
	technologyNameCounter=technologyNameCounter+1;
	technologyNames=[technologyNames;technologyT1Name];
		
	producerConcentrations=sum(newAgents(:,producerSkills));
	producerConcentrationsBufferSize=length(producerConcentrationsBuffer(:,1));
	newProducerConcentrationsBuffer=zeros(producerConcentrationsBufferSize,numberOfTechnologies);
	newProducerConcentrationsBuffer(2:producerConcentrationsBufferSize,1:numberOfTechnologies-1)=producerConcentrationsBuffer(1:producerConcentrationsBufferSize-1,:);
	newProducerConcentrationsBuffer(1,:)=producerConcentrations;		
	
	%new waste production associated to consumption (fixed it could be random)
	newWasteProduction=0.001;
	consumptionWasteGeneration=[consumptionWasteGeneration newWasteProduction];
	
	%update the input and output matrices considering waste generation
	inputMatrixWaste(numberOfProducts,:)=zeros(1,numberOfTechnologies-1);
	outputMatrixWaste(numberOfProducts,:)=zeros(1,numberOfTechnologies-1);
	inputVectorWasteT1=inputVectorT1;
	outputVectorWasteT1=outputVectorT1;
	outputVectorWasteT1(3)=0.001;	%fix amount of waste production it could be random
	inputMatrixWaste(:,numberOfTechnologies)=inputVectorWasteT1;
	outputMatrixWaste(:,numberOfTechnologies)=outputVectorWasteT1;
end%introduceNewConsumables()