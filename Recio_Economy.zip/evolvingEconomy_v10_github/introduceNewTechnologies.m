function [inputMatrix outputMatrix inputMatrixWaste outputMatrixWaste newAgents prices manufactured consumables numberOfProducts numberOfTechnologies productVectorIndex producerSkillsRelative producerSkills numberOfAgents newProducerIntroductionMatrix availableProducts targetStock productionBuffer productionStock profitVector profitBuffer meanProfits productNameCounter technologyNameCounter productNames technologyNames newProducerConcentrationsBuffer consumptionPatternRelativeIndex consumptionPatternIndex agentsProductionBuffer]=introduceNewTechnologies(targetTechnology,targetProfit,inputMatrix,outputMatrix,inputMatrixWaste,outputMatrixWaste,prices,manufactured,consumables,agents,producerIntroductionMatrix,targetStock,productionBuffer,profitBuffer,agentGlobalCounter,agentsProductionBuffer,productNameCounter,technologyNameCounter,productNames,technologyNames,producerConcentrationsBuffer,consumerAgents,consumptionPatternIndex),
	% -- Function file: 
	%	[inputMatrix outputMatrix newAgents 
	%	prices manufactured consumables 
	%	numberOfProducts numberOfTechnologies productVectorIndex 
	%	producerSkillsRelative producerSkills numberOfAgents 
	%	newProducerIntroductionMatrix availableProducts targetStock 
	%	productionBuffer productionStock profitVector 
	%	profitBuffer meanProfits productNameCounter 
	%	technologyNameCounter productNames technologyNames 
	%	newProducerConcentrationsBuffer consumptionPatternRelativeIndex consumptionPatternIndex
	%	agentsProductionBuffer]=
	%		introduceNewTechnologies(inputMatrix,outputMatrix,prices,
	%			manufactured,consumables,agents,
	%			producerIntroductionMatrix,targetStock,
	%			productionBuffer,profitBuffer,agentGlobalCounter,
	%			agentsProductionBuffer,productNameCounter,technologyNameCounter,
	%			productNames,technologyNames,producerConcentrationsBuffer,
	%			consumerAgents,consumptionPatternIndex)
	%
	% Summary: create a pair of technologies in order to replace a given technology (stated by targetTechnology
	% i.e. having the same production outcome but being produced using different products and resources)
	% where the final profit for the new production will be be targetProfit. In creating a pair of 
	% technologies intermediate products are created in the economy and therefore the number of products 
	% is increased. Both new technologies make use of capital products and there is certain depreciation 
	% of capital.
	
	numberOfCoordinates=2;
	numberOfIdentifiers=1;
	[numberOfProducts numberOfTechnologies]=size(inputMatrix);
	consumptionPattern=agents(consumerAgents,consumptionPatternIndex);
	depreciationOfCapital=0.1;
	
	% changes turn out into a new product and two new technologies
	numberOfProducts=numberOfProducts+1;
	inputMatrix(numberOfProducts,:)=zeros(1,numberOfTechnologies);
	outputMatrix(numberOfProducts,:)=zeros(1,numberOfTechnologies);
	
	%find out the capital and product of the target technology
	outputVector=outputMatrix(:,targetTechnology);
	inputVector=inputMatrix(:,targetTechnology);
	targetOutput=find(outputVector~=0);
	for productCounter=1:length(targetOutput),
		if ~inputVector(targetOutput(productCounter)),
			producedProduct=targetOutput(productCounter);
		else
			capitalProduct=targetOutput(productCounter);
		end
	end
	%select target production for both technologies
	targetProductT2=producedProduct;
	targetProductT1=numberOfProducts;
	%choose a capital good for both technologies (avoid choosing target product)
	poolOfProducts=manufactured(find(manufactured~=targetProductT2));
	capitalGoodT1=poolOfProducts(randi(length(poolOfProducts)));
	capitalGoodT2=poolOfProducts(randi(length(poolOfProducts)));
	%create technology vectors
	inputVectorT1=randi(2,numberOfProducts,1)-1;
	inputVectorT1(targetProductT1)=0;%do not use target product of T1 as input
	inputVectorT1(targetProductT2)=0;%do not use target product of T2 as input
	inputVectorT1(capitalGoodT1)=1;
	inputVectorT1(1)=1;%labour
	inputVectorT1(2)=0;%money
	inputVectorT1(3)=0;%waste
	compoundProducts=find(inputVectorT1~=0);
	inputVectorT1(compoundProducts)=rand(length(compoundProducts),1);
	outputVectorT1=zeros(numberOfProducts,1);
	outputVectorT1(targetProductT1)=1;
	outputVectorT1(capitalGoodT1)=inputVectorT1(capitalGoodT1)*(1-depreciationOfCapital);

	%the second technology only uses labour capital and the new product
	inputVectorT2=zeros(numberOfProducts,1);
	inputVectorT2(capitalGoodT2)=1;
	inputVectorT2(1)=1;%labour
	inputVectorT2(2)=0;%money
	inputVectorT2(3)=0;%waste
	inputVectorT2(numberOfProducts)=1;%always use the new product and capital
	compoundProducts=find(inputVectorT2~=0);
	inputVectorT2(compoundProducts)=rand(length(compoundProducts),1);
	outputVectorT2=zeros(numberOfProducts,1);
	outputVectorT2(targetProductT2)=1;
	outputVectorT2(capitalGoodT2)=inputVectorT2(capitalGoodT2)*(1-depreciationOfCapital);
	
	% %update the price of the new product
	% prices(numberOfProducts)=0;
	% prices(numberOfProducts)=prices*inputVectorT1-prices(capitalGoodT1)*outputVectorT1(capitalGoodT1); % 0 percent rate of return

	%work out the price from a normal distribution
	meanPrices=mean(prices);
	stdPrices=std(prices);
	prices(numberOfProducts)=0;
	price_bounded=abs(meanPrices+stdPrices*randn(1)); %bound the price of the new product with a normal distribution
	% price_bounded=abs(meanPrices+0.1*stdPrices*randn(1)); %bound the price of the new product with a normal distribution and 10% of the std
	% price_bounded=10*rand(1); %bound the price of the new product in the [0 10] range
	prices(numberOfProducts)=price_bounded;

	%work out what the production should be with the bounded price
	newOutProduction=(prices*inputVectorT1-prices(capitalGoodT1)*outputVectorT1(capitalGoodT1))/prices(targetProductT1);
	outputVectorT1(targetProductT1)=newOutProduction;

	%normalise vectors
	outputVectorT1=outputVectorT1/newOutProduction;
	inputVectorT1=inputVectorT1/newOutProduction;
	
	%work out the output coefficient for T2 such as satisfying target profit
	%outputCoefficientT2=(prices*inputVectorT2*targetProfit-prices(capitalGoodT2)*outputVectorT2(capitalGoodT2))/prices(targetProductT2);
	%the above line may create negative values for the output coefficients (targetProfit should multiply outside the subtraction term as below)
	outputCoefficientT2=(prices*inputVectorT2-prices(capitalGoodT2)*outputVectorT2(capitalGoodT2))*targetProfit/prices(targetProductT2);
	outputVectorT2(targetProductT2)=outputCoefficientT2; %set the output coefficient
	%normalise to one the output of production (this may be skipped leaving some other output coefficients)
	outputVectorT2=outputVectorT2/outputCoefficientT2;
	inputVectorT2=inputVectorT2/outputCoefficientT2;
	inputMatrix(:,numberOfTechnologies+1)=inputVectorT1;
	outputMatrix(:,numberOfTechnologies+1)=outputVectorT1;
	inputMatrix(:,numberOfTechnologies+2)=inputVectorT2;
	outputMatrix(:,numberOfTechnologies+2)=outputVectorT2;
	
	%allow new product to be choosen as a capital good for next executions
	manufactured=[manufactured targetProductT1];
	
	%update all related variables
	[numberOfProducts numberOfTechnologies]=size(inputMatrix);
	productVectorIndex=numberOfCoordinates+numberOfIdentifiers+1:numberOfCoordinates+numberOfIdentifiers+numberOfProducts;
	producerSkillsRelative=(1:numberOfTechnologies); %relative to the skill vector 1st to 4th
	producerSkills=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+producerSkillsRelative;
	
	[numberOfAgents agentsColumns]=size(agents);
	agentsColumns=agentsColumns+3; %one new product plus two new technologies
	newAgents=zeros(numberOfAgents,agentsColumns);
	newAgents(:,1:productVectorIndex(length(productVectorIndex)-1))=agents(:,1:productVectorIndex(length(productVectorIndex)-1));
	newAgents(:,producerSkills(1):producerSkills(length(producerSkills)-2))=agents(:,producerSkills(1)-1:producerSkills(length(producerSkills)-3));

	newProducerIntroductionMatrix=zeros(numberOfTechnologies,agentsColumns);

	newProducerIntroductionMatrix(1:numberOfTechnologies-2,1:productVectorIndex(length(productVectorIndex)-1))=producerIntroductionMatrix(:,1:productVectorIndex(length(productVectorIndex)-1));
	newProducerIntroductionMatrix(1:numberOfTechnologies-2,producerSkills(1):producerSkills(length(producerSkills)-2))=producerIntroductionMatrix(:,producerSkills(1)-1:producerSkills(length(producerSkills)-3));

	newProducerIntroductionMatrix(numberOfTechnologies-1,producerSkills(length(producerSkills)-1))=1;
	newProducerIntroductionMatrix(numberOfTechnologies,producerSkills(length(producerSkills)))=1;

	moneyIndex=productVectorIndex(2);
	freeGoodIndex=find(producerIntroductionMatrix(1,:)==inf);
	initialMoney=producerIntroductionMatrix(1,moneyIndex);
	initialStock=producerIntroductionMatrix(targetTechnology,productVectorIndex(targetProductT2));
	newProducerIntroductionMatrix(numberOfTechnologies-1:numberOfTechnologies,moneyIndex)=initialMoney;
	newProducerIntroductionMatrix(numberOfTechnologies-1,productVectorIndex(targetProductT1))=initialStock;
	newProducerIntroductionMatrix(numberOfTechnologies,productVectorIndex(targetProductT2))=initialStock;

	newProducerIntroductionMatrix(numberOfTechnologies,productVectorIndex(targetProductT2))=initialStock;

	newProducerIntroductionMatrix(numberOfTechnologies-1,freeGoodIndex)=inf;
	newProducerIntroductionMatrix(numberOfTechnologies,freeGoodIndex)=inf;

	% update the size for all related system variables
	availableProducts=sum(newAgents(:,productVectorIndex));
	targetStock(targetProductT1)=0;
	productionBuffer(:,targetProductT1)=zeros(length(productionBuffer(:,1)),1);
	productionStock=mean(productionBuffer,1);
	
	profitVector=(prices*outputMatrix)./(prices*inputMatrix);
	profitBuffer(:,numberOfTechnologies-1)=profitVector(numberOfTechnologies-1)*ones(length(profitBuffer(:,1)),1);
	profitBuffer(:,numberOfTechnologies)=profitVector(numberOfTechnologies)*ones(length(profitBuffer(:,1)),1);
	meanProfits=mean(profitBuffer,1);

	% introduce the new pair of agents
	agentType=numberOfTechnologies-1;
	[newAgents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock agentsProductionBuffer] = introduceNewAgent(agentType,newProducerIntroductionMatrix,agentGlobalCounter,newAgents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer);
	agentType=numberOfTechnologies;
	[newAgents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock agentsProductionBuffer] = introduceNewAgent(agentType,newProducerIntroductionMatrix,agentGlobalCounter,newAgents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer);

	productNameCounter=productNameCounter+1;
	newProductName=['P' num2str(productNameCounter)];
	productNames=[productNames;newProductName];
	
	technologyT1Name=['T' num2str(technologyNameCounter+1)];
	technologyT2Name=['T' num2str(technologyNameCounter+2)];
	technologyNameCounter=technologyNameCounter+2;
	technologyNames=[technologyNames;technologyT1Name;technologyT2Name];
	
	producerConcentrations=sum(newAgents(:,producerSkills));
	producerConcentrationsBufferSize=length(producerConcentrationsBuffer(:,1));
	newProducerConcentrationsBuffer=zeros(producerConcentrationsBufferSize,numberOfTechnologies);
	newProducerConcentrationsBuffer(2:producerConcentrationsBufferSize,1:numberOfTechnologies-2)=producerConcentrationsBuffer(1:producerConcentrationsBufferSize-1,:);
	newProducerConcentrationsBuffer(1,:)=producerConcentrations;
	
	numberOfConsumables=length(consumables);
	consumptionPatternRelativeIndex=1:numberOfConsumables;
	consumptionPatternIndex=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+numberOfTechnologies+consumptionPatternRelativeIndex;
	
	newAgents(consumerAgents,consumptionPatternIndex)=consumptionPattern;
	
	%update the input and output matrices considering waste generation
	inputMatrixWaste(numberOfProducts,:)=zeros(1,numberOfTechnologies-2);
	outputMatrixWaste(numberOfProducts,:)=zeros(1,numberOfTechnologies-2);
	inputVectorWasteT1=inputVectorT1;
	outputVectorWasteT1=outputVectorT1;
	outputVectorWasteT1(3)=0.001;	%fix amount of waste production it could be random

	inputVectorWasteT2=inputVectorT2;
	outputVectorWasteT2=outputVectorT2;
	outputVectorWasteT2(3)=0.001;	%fix amount of waste production it could be random

	inputMatrixWaste(:,numberOfTechnologies-1)=inputVectorWasteT1;
	outputMatrixWaste(:,numberOfTechnologies-1)=outputVectorWasteT1;
	inputMatrixWaste(:,numberOfTechnologies)=inputVectorWasteT2;
	outputMatrixWaste(:,numberOfTechnologies)=outputVectorWasteT2;
end%introduceNewTechnologies()