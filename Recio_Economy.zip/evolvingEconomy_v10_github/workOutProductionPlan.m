function [productionPlan] = workOutProductionPlan(activeAgent,profitVector,skillVectorIndex),
	% -- Function file: [productionPlan] = workOutProductionPlan(activeAgent,profitVector,skillVectorIndex)
	%
	% Summary: return a vector of size equal to number of technologies
	% representing the response to the agent production skills 
	% to the actual profits following a sigmoid function.
	% There will be one cell with the output production 
	% and the rest of cells will be zero.
	%
	% This will be one of the limiting factor of an agent's production
	% (money and stock would be the other factors).
	
	%set up parameters for sigmoid function 
	%defining the production output
	%that is alpha, offset and magnitude
	alpha=10;
	offsetC=1.0;
	maxProductionC=1.5;
	minProductionC=0;
	magnitudeC=maxProductionC-minProductionC;

	%initialise the production plan vector
	productionPlan=zeros(1,length(profitVector));
	%find out target technology of agent
	targetTechnology=find(activeAgent(skillVectorIndex)==1);
	%find out its profit
	profitValue=profitVector(targetTechnology);
	%apply sigmoid function and return vector
	productionPlan(targetTechnology)=minProductionC+magnitudeC*(1./(1+exp(-alpha*(profitValue-offsetC))));
end%workOutPlan()
