function [agents] = exchangeProducts(activeAgentIndex,agents,moneyIndex,productVectorIndex,producerSkills,requirements,prices,inputMatrix,outputMatrix),
	% -- Function file: [agents] = 
	%	exchangeProducts(activeAgentIndex,agents,moneyIndex,productVectorIndex,producerSkills,requirements,prices,inputMatrix,outputMatrix)
	% 
	% Summary: obtain requirements products for activeAgent from all remaining agents and
	% return the resulting agents matrix. In exchanging products money is involved
	% at current market prices.
	
	roundOffError=1e-9; %used to avoid negative zeros (or close to zero) due to numeric precision
	activeAgent=agents(activeAgentIndex,:);
	agents(activeAgentIndex,:)=0; %set own values to zeros to avoid choosing itself as seller
	for prodCounter=1:length(requirements),
		if requirements(prodCounter)>0,
			amountRequired=requirements(prodCounter);
			while amountRequired>0+roundOffError,
				%find producers
				if prodCounter==1,
					poolOfProducers=find(sum(agents(:,producerSkills),2)==0);%all consumers produce labour
				else
					poolOfProducers=findProducers(agents(:,producerSkills),prodCounter,inputMatrix,outputMatrix);
				end
				%find sellers
				poolOfSellers=poolOfProducers(find(agents(poolOfProducers,productVectorIndex(prodCounter))>0));
				sellerAgentIndex=poolOfSellers(randi(length(poolOfSellers)));
				sellerAgent=agents(sellerAgentIndex,:);
				%exchange goods and money (update stock)
				if sellerAgent(productVectorIndex(prodCounter))>=amountRequired,
					%obtain all goods from one provider
					totalPurchase=amountRequired;
					sellerAgent(productVectorIndex(prodCounter))=sellerAgent(productVectorIndex(prodCounter))-totalPurchase;
					sellerAgent(moneyIndex)=sellerAgent(moneyIndex)+totalPurchase*prices(prodCounter);
					% update active agent outside the loop to avoid round off errors
					% activeAgent(productVectorIndex(prodCounter))=activeAgent(productVectorIndex(prodCounter))+totalPurchase;
					activeAgent(moneyIndex)=activeAgent(moneyIndex)-totalPurchase*prices(prodCounter);
					amountRequired=0;
					%update matrix
					agents(sellerAgentIndex,:)=sellerAgent;
				else
					%obtain the goods from several providers
					totalPurchase=sellerAgent(productVectorIndex(prodCounter));
					sellerAgent(productVectorIndex(prodCounter))=0;
					sellerAgent(moneyIndex)=sellerAgent(moneyIndex)+totalPurchase*prices(prodCounter);
					% update active agent outside the loop to avoid round off errors
					% activeAgent(productVectorIndex(prodCounter))=activeAgent(productVectorIndex(prodCounter))+totalPurchase;
					activeAgent(moneyIndex)=activeAgent(moneyIndex)-totalPurchase*prices(prodCounter);
					amountRequired=amountRequired-totalPurchase;
					%update matrix
					agents(sellerAgentIndex,:)=sellerAgent;
				end%if
			end%while()
		end%if()
	end%for()
	% update active agent outside the loop to avoid round off errors
	% save the money first then update requirements and get money back into agent
	money=activeAgent(moneyIndex);
	activeAgent(productVectorIndex)=activeAgent(productVectorIndex)+requirements;
	activeAgent(moneyIndex)=money;
	%update matrix with active agent
	agents(activeAgentIndex,:)=activeAgent;	
end%exchangeProducts()
