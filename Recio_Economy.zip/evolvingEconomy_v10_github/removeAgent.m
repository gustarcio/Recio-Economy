function [agents numberOfAgents producerAgents consumerAgents targetStock agentsProductionBuffer dumpField] = removeAgent(agentPosition,agents,targetStock,producerSkills,productVectorIndex,inputMatrix,outputMatrix,agentsProductionBuffer,dumpField),
	% -- Function file: [agents numberOfAgents producerAgents consumerAgents targetStock agentsProductionBuffer] =
	%	removeAgent(agentPosition,agents,targetStock,producerSkills,productVectorIndex,inputMatrix,outputMatrix,agentsProductionBuffer)
	%
	% Summary: remove an agent from the system updating all related 
	% matrices and vectors. The agent to be removed is indicated
	% by agentPosition within the agents matrix (particular row 
	% to be removed).
	
	% it is important to remove the initial stock 
	% from the system target stock to avoid any type 
	% of change in the prices due to this agent removal
	initialStock=10;
	% store the actual data to be removed
	targetAgent=agents(agentPosition,:);
	% actual removal of row in agents matrix
	agents(agentPosition,:)=[];
	% and update all related system variables
	agentsProductionBuffer(agentPosition,:)=[];
	[numberOfAgents columnOfAgentsMatrix]=size(agents);
	producerAgents=find(sum(agents(:,producerSkills),2)>0)';
	consumerAgents=find(sum(agents(:,producerSkills),2)==0)';
	%find out what product the agent was producing (to remove initial values from target stock)
	targetTechnology=find(targetAgent(producerSkills)==1);
	inputVector=inputMatrix(:,targetTechnology);
	outputVector=outputMatrix(:,targetTechnology);
	%localise the capital product (if any) and target product (to remove inital values from target stock)
	targetProducts=find(outputVector>0);
	productionOutput=[];
	capitalProduct=[];
	for productCounter=1:length(targetProducts),
		if inputVector(targetProducts(productCounter))==0,
			% this is what we aim for
			productionOutput=targetProducts(productCounter);
		else
			% this product is capital
			capitalProduct=targetProducts(productCounter);
		end
	end
	%actual removal of initial values from the target stock
	targetStock(productionOutput)=targetStock(productionOutput)-initialStock;
	%fill the dump field with waste from target agent
	dumpField=dumpField+targetAgent(6);%relative position 3 plus x and y coordinates plus agent id
end%introduceNewAgent()