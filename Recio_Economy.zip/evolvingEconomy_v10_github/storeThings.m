function [myRecord] = storeThings(productNames,prices,availableProducts,technologyNames,profitVector,producerConcentrations,producerConsumerBalance),
	% -- Function file: [myRecord] = storeThings(productNames,prices,availableProducts,technologyNames,profitVector,producerConcentrations)
	%
	% Summary: return a struct variable with the following fields:
	%	productNames
	%	prices
	%	availableProducts
	%	technologyNames
	%	profitVector
	%	producerConcentrations
	%  producerConsumerBalance
	%
	% This variable is used to visualise and monitor the system
	
	myRecord=struct('productNames',productNames,'prices',prices,'availableProducts',availableProducts,'technologyNames',technologyNames,'profitVector',profitVector,'producerConcentrations',producerConcentrations,'producerConsumerBalance',producerConsumerBalance);	
end