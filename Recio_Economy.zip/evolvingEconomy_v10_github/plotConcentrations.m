function [] = plotConcentrations(HF,myRecord,varargin),
	% -- Function file: plotConcentrations(HF,myRecord,varargin)
	%
	% Summary: plot a figure with handle HF with the stored
	% data in the field producerConcentrations of the struc 
	% myRecord matching the names in varargin
	%
	% example: plotConcentrations(104,myRecords,'T1','T2')
	
	% check for cell input in function heading
	if iscell(varargin{1}),
		varargin=varargin{1}; %modify varargin accordingly
	end	
	
	figure(HF)
	clf(HF)
	% find out the number of plots
	numberOfPlots=length(varargin);
	% create a platette of colours
	palette = jet(numberOfPlots);
	% for every plot to be done (varargin)
	for plotCounter=1:numberOfPlots,
		%find out the iterations at which such name
		%existed in the system and its value
		xRange=[]; %actual iterations
		toPlot=[]; %actual values
		storingCounter=1; %accounts for the existence of a given technology (in iterations)
		for iterationCounter=1:length(myRecord),
			% fill with characteres (default is blank) if different sizes
			% just for comparison purposes
			technologies=myRecord(iterationCounter).technologyNames; %take the actual names
			targetNamesMatrix=[technologies;varargin{plotCounter}]; %auto-fill matrix (compared against varargin name)
			targetName=targetNamesMatrix(length(targetNamesMatrix),:); %get the name to be compared with the rigth size (character filled matrix)
			for techCounter=1:length(technologies),
				%actual comparison
				if sum(targetNamesMatrix(techCounter,:)==targetName)==length(targetNamesMatrix(techCounter,:)),
					%then store in the variables to plot
					producerConcentrations=myRecord(iterationCounter).producerConcentrations;
					toPlot(storingCounter)=producerConcentrations(techCounter);
					xRange(storingCounter)=iterationCounter;
					storingCounter=storingCounter+1;
				end
			end
		end
		%plot figure and set labels
		hold on
		plot(xRange,toPlot,'-','linewidth',2);
		h=get(gca,'children')';
		set(h(1),'color',palette(plotCounter,:));
		hold off		
	end
	legend(varargin,'location','eastoutside')
	xlabel('Iterations')
	ylabel('number of producers')
end%plotResults()