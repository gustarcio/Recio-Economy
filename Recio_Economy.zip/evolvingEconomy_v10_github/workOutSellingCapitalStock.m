function [sellingStock capitalStock availableProducts] = workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills),
	% -- Function file: [sellingStock capitalStock availableProducts] = workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills)
	%
	% Summary: this function returns three variables accounting for all existing
	% products in the market economy and separating them as products 
	% available for selling, being used as capital products and the sum 
	% of all products.
	
	[numberOfProducts numberOfTechnologies]=size(outputMatrix);
	%identify output products (produced and capital in output matrix)
	nonZeroOutput=find(outputMatrix~=0);
	%find out which one of them are not capital (those in the output matrix with zero input)
	nonCapitalOutput=nonZeroOutput(find(inputMatrix(nonZeroOutput)==0));
	%find out the capital products (just the opposite)
	capitalCells=nonZeroOutput(find(inputMatrix(nonZeroOutput)~=0));
	% compute all existing products
	availableProducts=sum(agents(:,productVectorIndex));
	%initial values for selling and capital
	sellingStock=zeros(1,numberOfProducts);
	capitalStock=zeros(1,numberOfProducts);
	%create matrices representing capital and production outcome
	productionMatrix=zeros(numberOfProducts,numberOfTechnologies);
	capitalMatrix=zeros(numberOfProducts,numberOfTechnologies);
	productionMatrix(nonCapitalOutput)=1;
	capitalMatrix(capitalCells)=1;
	%for each existing product 
	for targetProduct=1:numberOfProducts,
		%find out what technologies are producing it
		targetTechnologies=find(productionMatrix(targetProduct,:)==1);
		if ~isempty(targetTechnologies),
			%find out what agents have such technology and arrange capital and for sale
			poolOfProducers=find(sum(agents(:,producerSkills(targetTechnologies))==1,2)>0);
			if ~isempty(poolOfProducers),
				%if there are producers -> some is produced and some may be capital
				qttyForSale=sum(agents(poolOfProducers,productVectorIndex(targetProduct)));
				capitalStock(targetProduct)=availableProducts(targetProduct)-qttyForSale;
			else
				%all is capital (no producers)
				capitalStock(targetProduct)=availableProducts(targetProduct);
			end
		end
	end
	%update the sellingStock variable
	sellingStock=availableProducts-capitalStock;
end%workOutSellingCapitalStock()