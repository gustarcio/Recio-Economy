function [agentProduction agentConsumption] = performProduction(productionPlan,inputMatrix,outputMatrix),
	% -- Function file: [agentProduction agentConsumption] = performProduction(productionPlan,inputMatrix,outputMatrix)
	%
	% Summary: return the production and consumption as stated in vonNeumann matrices
	% and a given production plan for an agent
	
	% production output (including capital products)
	agentProduction=(outputMatrix*productionPlan')';
	% required inputs
	agentConsumption=(inputMatrix*productionPlan')';
end
