function [] = plotAll(workingFolderPath),
	% -- Function file: plotAll(workingFolderPath)
	%
	% Summary: plot the figures related to current 
	% experiment in in the folder description
	%
	% It makes use of several plot routines that can
	% be found in the working folder (e.g. plotPrices)
	%
	% example: plotAll('./') or plotAll('../../../evolvingEconomy_v10_github')
	
	
	
	
	
	
	
	
	
	% load run004.data
	% str=['new technology input vector:' num2str(inputMatrix(:,5)') '\nnew technology output vector: '  num2str(outputMatrix(:,5)') '\n'];
	% printf(str);
	% myPath='/Users/Gustavo/GoogleDrive/MUN/allTogether/paperTests';
	% addpath(myPath)
	% plotPrices(101,myRecords,'P5','P6','P7','P8')
	% plotAvailable(102,myRecords,'P5','P6','P7','P8');
	% plotProfits(103,myRecords,'T1','T2','T3','T4');
	% rmpath(myPath)
	% figure(101),
	% grid on
	% legend('P4','P5','P6','P7')
	% axis([1 500 0 3])
	% figure(102),
	% grid on
	% legend('P4','P5','P6','P7')
	% axis([1 500 0 100])
	% figure(103),
	% hold on
	% plot(techT6profit,'k','linewidth',2)
	% hold off
	% grid on
	% axis([1 500 0.8 1.2])
	% legend('T1','T2','T3','T4','T6')
	%
	% print(101,'results011.eps','-deps','-F:12','-color');
	% print(102,'results012.eps','-deps','-F:12','-color');
	% print(103,'results013.eps','-deps','-F:12','-color');
	
	

	
	load simulationData001.data;
	for counter=1:500,
		techT6profit(counter)=myRecords(counter).profitVector(5);
	end
	addpath(workingFolderPath);
	plotPrices(101,myRecords,'P5','P6','P7','P8')
	plotAvailable(102,myRecords,'P5','P6','P7','P8');
	plotProfits(103,myRecords,'T1','T2','T3','T4');
	rmpath(workingFolderPath);
	figure(101),
	grid on
	legend('P4','P5','P6','P7','location','northeast')
	axis([1 500 0 3])
	figure(102),
	grid on
	legend('P4','P5','P6','P7','location','northeast')
	axis([1 500 0 100])
	figure(103),
	hold on
	plot(techT6profit,'k','linewidth',2)
	hold off
	grid on
	axis([1 500 0.8 1.2])
	legend('T1','T2','T3','T4','T6','location','northeast')

	print(101,'results011.eps','-deps','-F:12','-color');
	print(102,'results012.eps','-deps','-F:12','-color');
	print(103,'results013.eps','-deps','-F:12','-color');

	close all

end% plotAll()
