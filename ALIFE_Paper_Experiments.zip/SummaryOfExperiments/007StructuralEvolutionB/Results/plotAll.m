function [] = plotAll(workingFolderPath),
	% -- Function file: plotAll(workingFolderPath)
	%
	% Summary: plot the figures related to current 
	% experiment in in the folder description
	%
	% It makes use of several plot routines that can
	% be found in the working folder (e.g. plotPrices)
	%
	% example: plotAll('./') or plotAll('../../../evolvingEconomy_v10_github')

	printf('\nPrinting out figures... this may take a while.\n ');
	fflush(stdout);
	
	load simulationData001.data;
	addpath(workingFolderPath);

	figure(104),

	plotAvailable(104,myRecords,products2Plot);

	legend off
	myH=legend(products2Plot);
	set(myH, "fontsize", 6,'location','eastoutside');

	myH=get(gcf,'currentaxes');
	set(myH, "fontsize", 12)

	myH = xlabel ('Iterations');
	set(myH, "fontsize", 12)

	myH = ylabel ('Prices');
	set(myH, "fontsize", 12)

	print(104,'Run32-Fig104.eps','-deps','-color');

	figure(105),
	plotProducerConsumerBalance(105,myRecords);

	legend off
	myH=legend('Producers','Consumers');
	set(myH, "fontsize", 6,'location','eastoutside');

	myH=get(gcf,'currentaxes');
	set(myH, "fontsize", 12)

	myH = xlabel ('Iterations');
	set(myH, "fontsize", 12)

	myH = ylabel ('Global number of producers and consumers');
	set(myH, "fontsize", 12)

	print(105,'Run32-Fig105.eps','-deps','-color');

	for counter=1:iterations,
		consumersPerIt(counter)=myRecords(counter).producerConsumerBalance(2);
		techsPerIt(counter)=length(myRecords(counter).technologyNames);
		productsPerIt(counter)=length(myRecords(counter).productNames);
	end%for

	%use the plotAvailable function modified below to obtain the data
	toPlotRaw=plotAvailable(123,myRecords,'P5');
	close(123);

	consumersRawMaterialPerIt=consumersPerIt./toPlotRaw;

	itcounter=1:iterations;
	myData=[itcounter' techsPerIt' productsPerIt' toPlotRaw' consumersPerIt' consumersRawMaterialPerIt'];

	figure(101),
	plot(myData(:,1),myData(:,2))
	%title('Technologies per iteration');
	xlabel('Iterations');
	ylabel('Number of technologies');

	figure(102),
	plot(myData(:,1),myData(:,3))
	%title('Products per iteration');
	xlabel('Iterations');
	ylabel('Number of products');

	figure(105),
	plot(myData(:,1),myData(:,6))
	%title('Consumers - raw material ratio');
	xlabel('Iterations');
	ylabel('Efficiency');

	print(101,'Run32TechperIt.eps','-deps','-F:12','-color');
	print(102,'Run32ProdperIt.eps','-deps','-F:12','-color');
	print(105,'Run32Efficiency.eps','-deps','-F:12','-color');
	
	figure(501),
	plotConcentrations(501,myRecords,'T8', 'T19', 'T21', 'T23', 'T25', 'T31')
	print(501,'Run32TechCoExistence.eps','-deps','-F:12','-color');

	rmpath(workingFolderPath);

	close all
	clear all
end% plotAll()




function [toPlot] = plotAvailable(HF,myRecord,varargin),
	% -- Function file: plotPrices(HF,myRecord,varargin)
	%
	% Summary: plot a figure with handle HF with the stored
	% data in the field prices of the struc 
	% myRecord matching the names in varargin
	%
	% example: plotPrices(102,myRecords,'P1','P2')
	
	% check for cell input in function heading
	if iscell(varargin{1}),
		varargin=varargin{1}; %modify varargin accordingly
	end	
	
	figure(HF)
	clf(HF)
	% find out the number of plots
	numberOfPlots=length(varargin);
	% create a platette of colours
	palette = jet(numberOfPlots);
	% for every plot to be done (varargin)
	for plotCounter=1:numberOfPlots,
		%find out the iterations at which such name
		%existed in the system and its value
		xRange=[]; %actual iterations
		toPlot=[]; %actual values
		storingCounter=1; %accounts for the existence of a given technology (in iterations)
		for iterationCounter=1:length(myRecord),
			% fill with characteres (default is blank) if different sizes
			% just for comparison purposes
			products=myRecord(iterationCounter).productNames;  %take the actual names
			targetNamesMatrix=[products;varargin{plotCounter}]; %auto-fill matrix (compared against varargin name)
			targetName=targetNamesMatrix(length(targetNamesMatrix),:);%get the name to be compared with the rigth size (character filled matrix)
			for productCounter=1:length(products),
				%actual comparison
				if sum(targetNamesMatrix(productCounter,:)==targetName)==length(targetNamesMatrix(productCounter,:)),
					%then store in the variables to plot
					availableProducts=myRecord(iterationCounter).availableProducts;
					toPlot(storingCounter)=availableProducts(productCounter);
					xRange(storingCounter)=iterationCounter;
					storingCounter=storingCounter+1;
				end
			end
		end
		%plot figure and set labels
		hold on
		plot(xRange,toPlot,'-','linewidth',2);
		h=get(gca,'children')';
		set(h(1),'color',palette(plotCounter,:));
		hold off		
	end
	legend(varargin,'location','eastoutside')
	xlabel('Iterations')
	ylabel('Available Products')
end%plotResults()
