function [] = plotAll(workingFolderPath),
	% -- Function file: plotAll(workingFolderPath)
	%
	% Summary: plot the figures related to current 
	% experiment in in the folder description
	%
	% It makes use of several plot routines that can
	% be found in the working folder (e.g. plotPrices)
	%
	% example: plotAll('./') or plotAll('../../../evolvingEconomy_v10_github')
	
	load simulationData001.data;
	addpath(workingFolderPath);
	plotPrices(101,myRecords,'P5','P6','P7','P8')
	plotAvailable(102,myRecords,'P5','P6','P7','P8');
	plotProfits(103,myRecords,'T1','T2','T3','T4');
	rmpath(workingFolderPath);
	figure(101),
	grid on
	legend('P4','P5','P6','P7','location','northeast')
	axis([1 500 0 3])
	figure(102),
	grid on
	legend('P4','P5','P6','P7','location','northeast')
	axis([1 500 0 160])
	hold on;
	plot([50 55 60 65 70],[70 80 90 100 110],'.k');
	hold off;
	figure(103),
	grid on
	legend('T1','T2','T3','T4','location','northeast')
	axis([1 500 0.8 1.2])

	print(101,'results004.eps','-deps','-F:12','-color');
	print(102,'results005.eps','-deps','-F:12','-color');
	print(103,'results006.eps','-deps','-F:12','-color');

	close all

end% plotAll()
