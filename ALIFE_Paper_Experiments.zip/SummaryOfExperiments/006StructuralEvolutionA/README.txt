File README.txt

Evolution with crises

##########################

Summary: 

Typical successfully evolving system with a crisis.

##########################

Contents: 

Readme.txt, mainEconomy.txt, Results(folder)

The file mainEconomy.m contains the configuration parameters of the current experiment.

The Results folder contains the simulationData.data file with the results of the current experiment, the plotAll.m routine that can be used to reproduce the figures shown in the paper that are related to the current experiment, and a copy of those figures for easy access.

##########################

Reproducibility:


To reproduce the run of the current experiment move (and replace when applicable) the file mainEconomy.m into the working folder where RecioEconomy.zip has been uncompressed. Then execute the script file mainEconomy.m from the octave prompt.

The execution will generate a result file called simulationData.data. This result file can be loaded from the plotAll.m routine to reproduce the figures shown in the paper.

plotAll is a plotting routine function that takes an argument describing the path where the RecioEconomy.zip has been uncompressed.

##########################