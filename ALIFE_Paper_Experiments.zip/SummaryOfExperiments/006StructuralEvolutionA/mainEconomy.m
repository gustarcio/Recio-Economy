%********************************************************************************%
% MAIN FILE: mainEconomy.m																			%
% Created by Gustavo Recio																			%
%																											%
% Department of Computer Science																	%
% Memorial University of Newfoundland															%
% April, 2016 - St. John's Newfoundland														%
% Revised April 2020
% Check for random seed behavior             %
% Intervention determined on line 236-238         %											
% Main Loop line 240                  %
%																%
% This code implements an agent based modelling economy 									%
% using production processes as described in vonNeumann 									%
% production matrices and simulates the dynamics of the 									%
% economy by means of applying the market forces, i.e. 									%
% adjusting the product prices on the basis of supply 									%
% and demand figures. 																				%
%																											%
% The economy starts with eigth products and four technologies.						%
% During the simulation the economy evolves towards increasing							%
% its complexity by the introduction of new products and 								%
% technologies.																						%
% 																											%
% This program makes use of the following dependent function files:					%
%																											%
%	exchangeProducts.m		removeAgent.m				viableExcessConsumption.m		%
%	producerCheck.m			viableMinimumPlan.m		workOutPricesRational.m			%
%	findProducers.m			performProduction.m		workOutProductionPlan.m			%
%	plotConcentrations.m		removeTechnology.m		introduceNewConsumable.m		%
%	plotAvailable.m			introduceNewAgent.m		workOutSellingCapitalStock.m	%	
%	plotPrices.m				storeThings.m				introduceNewTechnologies.m		%
%	plotProfits.m				variableProductionPlan.m										%
%																											%
%********************************************************************************%

clear all
% close all

%*********************************
% GLOBAL VARIABLES (if any)
%*********************************
global STOP=0; %used to access the debugger through the keyboard command (not used in this version of the code)

%**************************************************
% RANDOM NUMBER SEED SET TO N: RAND('STATE',N)
%**************************************************
n=961;  %THIS IS THE SEED - CHANGE IF YOU WANT A DIFFERENT RUN!!!
rand("seed",n);
randn("seed",n);


%*********************************
% CREATE LOG FILE
%*********************************
writeToLog=1;
runningBar=['-\|/'];
runningBarCounter=1; %used to access the above vector and show the running bar
showRunningBarBlock=25; %iterations to show the running bar (going in circles)
blockSize=100; %iterations to update on screen information 
if writeToLog,
	logFileName='logFile.txt';
	printf('Log for the execution of mainEconomy.m \n%s\n---\n', date);
	fflush(stdout);
	logFileID=fopen(logFileName,'w');
	fprintf(logFileID,'Log file for the execution of mainEconomy.m \n%s\n---\n', date);
	fclose(logFileID);
else
	printf('Executing mainEconomy.m\n')
	printf('%s',runningBar(1));
	fflush(stdout);
end
%*********************************
% SET UP INITIAL PARAMETERS
%*********************************
removalPercentage=0.05; %this is used to allow multiple agent removals without removing the entire population

upperLimitLabour=2; %this amount is updated and available to be traded per consumer per iteration

roundOffPrecision=1e-10; %used to avoid negative zeros (or close to zero) due to numeric precision
productiveThreshold=0.3*1.5; %all producers producing less than half the maximum (30%) can be removed

productNames=['P1';'P2';'P3';'P4';'P5';'P6';'P7';'P8'];
technologyNames=['T1';'T2';'T3';'T4'];

productNameCounter=8;
technologyNameCounter=4;

% initial vonNeumann input and output matrices
inputMatrix = [1, 2/3, 1/2, 1; ...
	 				0, 0, 0, 0; ...
					0, 0, 0, 0; ...
	 				0, 2/3, 0, 0; ...
	 				0, 2/3, 0, 0; ...
	 				0, 0, 1/2, 0; ...
	 				0, 0, 0, 1; ...
					0, 0, 0, 0];
outputMatrix= [0 0 0 0; ...
					0 0 0 0; ...
					0 0 0 0; ...
					0 0 0 0; ...
					1 0 0 0; ...
					0 1 0 0; ...
					0 0 1 0; ...
					0 0 0 1];

% initial vonNeumann input and output matrices with waste
inputMatrixWaste = [1, 2/3, 1/2, 1; ...
	 				0, 0, 0, 0; ...
					0, 0, 0, 0; ...
	 				0, 2/3, 0, 0; ...
	 				0, 2/3, 0, 0; ...
	 				0, 0, 1/2, 0; ...
	 				0, 0, 0, 1; ...
					0, 0, 0, 0];
outputMatrixWaste= [0 0 0 0; ...
					0 0 0 0; ...
					0.001 0.001 0.001 0.001; ...
					0 0 0 0; ...
					1 0 0 0; ...
					0 1 0 0; ...
					0 0 1 0; ...
					0 0 0 1];
					


[numberOfProducts numberOfTechnologies]=size(inputMatrix);

manufactured=[5 6 7];
consumables=[8];

consumptionWasteGeneration=[0.01];

dumpField=0;

%*********************************
% WRITE TO LOG FILE
%*********************************
if writeToLog,
	printMatrices (logFileName,inputMatrix,outputMatrix,manufactured,consumables,productNames,technologyNames);
end		

numberOfConsumables=length(consumables);

prices=[1.00000 1.00000 0.00000 0.00000 1.00000 1.33333 1.16667 2.16667];
profitVector=(prices*outputMatrix)./(prices*inputMatrix);

%create different type of agent templates
numberOfCoordinates=2; %x and y coordinates
numberOfIdentifiers=1; %agent id is just a number
iterationsForSurvival=5;
minConsumptionC=0.15;
priceC=prices(consumables);
survivalAmount=iterationsForSurvival*priceC*minConsumptionC;
initialStock=10;
initialMoney=10;
skills=[1 0 0 0];
producerT1=[0 0 0 0 initialMoney 0 inf initialStock 0 0 0 skills 0];
skills=[0 1 0 0];
producerT2=[0 0 0 0 initialMoney 0 inf 0 initialStock 0 0 skills 0];
skills=[0 0 1 0];
producerT3=[0 0 0 0 initialMoney 0 inf 0 0 initialStock 0 skills 0];
skills=[0 0 0 1];
producerT4=[0 0 0 0 initialMoney 0 inf 0 0 0 initialStock skills 0];
skills=[0 0 0 0];
initialMoney=1.2*survivalAmount; % this is a bit more than the survival amount
producerT5=[0 0 0 initialStock initialMoney eps inf 0 0 0 0 skills 1];
%actual template for producers and consumers
producerIntroductionMatrix=[producerT1;producerT2;producerT3;producerT4];
consumerIntroductionMatrix=[producerT5]; %not being used
%initialise the agents matrix
agents=[producerT1;producerT1;producerT2;producerT2;producerT2;producerT3;producerT3;producerT3;producerT3;producerT3;producerT3;producerT4;producerT4;producerT4;producerT4;producerT4;producerT4;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5;producerT5];
[numberOfAgents columnOfAgentsMatrix]=size(agents);
%choose a location for each agent
agents(:,3)=1:numberOfAgents; % agent's id
%assign an ID to each agent
agents(:,[1 2])=randi(100,numberOfAgents,2); % x and y coordinates (agent's location)
agentGlobalCounter=numberOfAgents; %used to create further agents identifiers

%find out absolute and relative positions of products with respect to product vector and agents matrix
productVectorIndex=numberOfCoordinates+numberOfIdentifiers+1:numberOfCoordinates+numberOfIdentifiers+numberOfProducts;
%with respect to product vector relative position
relativePositionLabour = 1;
relativePositionMoney = 2;
relativePositionWasteProduct = 3;
relativePositionFreeGood = 4;
producerSkillsRelative=1:numberOfTechnologies; %relative to the skill vector 1st to 4th
consumptionPatternRelativeIndex=1:numberOfConsumables;
%with respect to agents matrix absolute position
labourPosition=relativePositionLabour+numberOfCoordinates+numberOfIdentifiers;
moneyIndex=relativePositionMoney+numberOfCoordinates+numberOfIdentifiers;
freeGoodPosition=relativePositionFreeGood+numberOfCoordinates+numberOfIdentifiers;
wasteProductPosition=relativePositionWasteProduct+numberOfCoordinates+numberOfIdentifiers;
producerSkills=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+producerSkillsRelative;
consumptionPatternIndex=numberOfCoordinates+numberOfIdentifiers+numberOfProducts+numberOfTechnologies+consumptionPatternRelativeIndex;

%create a list of producers and consumers
producerAgents=find(sum(agents(:,producerSkills),2)>0)';
consumerAgents=find(sum(agents(:,producerSkills),2)==0)';

%work out system wide stock
availableProducts=sum(agents(:,productVectorIndex));

%setting the number of windows (windowSize will be updated on the main loop)
totalWindows=1;
iterationsInBuffer=5;
bufferSize=iterationsInBuffer*totalWindows; %the buffer accounts for 5 iterations, i.e. 5 times number of windows storaging of things

%initial stock used to adjust prices
targetStock=availableProducts;

%this is used in the price adjustment
productionBuffer=zeros(bufferSize,numberOfProducts);
productionStock=mean(productionBuffer,1);

%this is used to remove agents that are not active
agentsProductionBufferSize=5;
agentsProductionBuffer=zeros(numberOfAgents,agentsProductionBufferSize);

%this is used to assess the profitability of technologies with several purposes
% introducing new agents, creating new technologies and products, etc.
iterationsInProfitBuffer=5;
profitBufferSize=iterationsInProfitBuffer*totalWindows;
profitBuffer=zeros(profitBufferSize,numberOfTechnologies);

%this is used to remove technologies and show the number of producers having a given technology
iterationsInProducerConcentrationBuffer=5;
producerConcentrationsBufferSize=iterationsInProducerConcentrationBuffer*totalWindows;
producerConcentrationsBuffer=zeros(producerConcentrationsBufferSize,numberOfTechnologies);

%initialise the storying variable myRecords
producerConcentrations=sum(agents(:,producerSkills));
producerConsumerBalance=[length(producerAgents) length(consumerAgents)];
storingCounter=1;
[myRecords(storingCounter,:)] = storeThings(productNames,prices,availableProducts,technologyNames,profitVector,producerConcentrations,producerConsumerBalance);

%interventions on consumer side
#interventionPeriod=[250 275];%iteration at which intervention starts and ends
interventionPeriod=[0 0];%iteration at which intervention starts and ends
%*********************************
% MAIN LOOP
%*********************************
for iterations=1:10000,
	if ~writeToLog,
		% print information (in blocks) about the current execution 
		if mod(iterations,blockSize)==0,
			printf('\bExecuting iteration %d\n ',iterations);
			fflush(stdout);
		end
		% print the running bar going in circles
		if ~mod(iterations,showRunningBarBlock)
			printf('\b%s',runningBar(mod(runningBarCounter+5,4)+1));
			fflush(stdout);
			runningBarCounter=runningBarCounter+1;
		end
	end

	% update the maximum production of labour per agent per iteration
	agents(consumerAgents,labourPosition)=upperLimitLabour*ones(length(consumerAgents),1);	
	absoluteLabour=sum(agents(:,labourPosition));
	% vector of random index for taking turns
	randVector=randperm(numberOfAgents); 
	windowSize=ceil(numberOfAgents/totalWindows);

	poolOfNominatedAgents=[];
	nominatedAgents=[];
	totalConsumptionConsumable=0;
	consumerCounter=1;
	excessMoneyBuffer=zeros(1,length(consumerAgents));

	%*********************************
	% WINDOW SYSTEM
	%*********************************
	% if numberOfWindows is larger than 1 then 
	% prices are updated several times per iteration
	for windowIndex=1:totalWindows,
		%initialise production
		productionMatrix=zeros(numberOfAgents,numberOfProducts);
		consumptionMatrix=zeros(numberOfAgents,numberOfProducts);
		agentsProductionBuffer(:,2:agentsProductionBufferSize)=agentsProductionBuffer(:,1:agentsProductionBufferSize-1);
		%compute the profits
		profitVector=prices*outputMatrix./(prices*inputMatrix);
		if windowIndex==totalWindows,
			lastOfWindow=length(randVector)-(windowIndex-1)*windowSize;
		else
			lastOfWindow=windowSize;
		end
		for agentIndex=1:lastOfWindow,
			%select an agent (at random)
			activeIndex=randVector((windowIndex-1)*windowSize+agentIndex);
			activeAgent=agents(activeIndex,:);
			%producer/consumer check
			if producerCheck(activeAgent,producerSkills),
				%producer agent
				%work out a production plan
				[productionPlan] = variableProductionPlan(activeIndex,agents,producerSkills,productVectorIndex,inputMatrix,outputMatrix,moneyIndex,prices);
				%check for available products vs requirements and enough money
				[agentProduction totalRequirements]=performProduction(productionPlan,inputMatrixWaste,outputMatrixWaste);
				requirements=zeros(1,numberOfProducts);
				requirementsIndexes=find(totalRequirements>0);
				posessions=activeAgent(productVectorIndex);
				for productCounter=1:length(requirementsIndexes),
					if posessions(requirementsIndexes(productCounter))<totalRequirements(requirementsIndexes(productCounter)),
						requirements(requirementsIndexes(productCounter))=totalRequirements(requirementsIndexes(productCounter))-posessions(requirementsIndexes(productCounter));
					end
				end
				% work out global stock in market (product for sale - not including capital)
				[sellingStock capitalStock availableProducts]=workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills);
				agentMoney=activeAgent(moneyIndex);
				requirementsCost=prices*requirements';
				if (sum((sellingStock-posessions-requirements)<0)==0)&&(agentMoney>requirementsCost)&&(sum(productionPlan)>productiveThreshold),
					%go ahead with production plan
					activeProduction=1;
					agentsProductionBuffer(activeIndex,1)=activeProduction;
				else
					%change production plan to adapt to current stock
					activeProduction=1; %with this we perform some sort of production
					agentsProductionBuffer(activeIndex,1)=0; %even though the agent's production is below the Executingminimum (it may be removed)
				end
				if (activeProduction),
				% There is always a bit of production so above condition may be removed
					%actual exchange
					agents=exchangeProducts(activeIndex,agents,moneyIndex,productVectorIndex,producerSkills,requirements,prices,inputMatrix,outputMatrix);
					%reserve the consumption of required products
					agents(activeIndex,productVectorIndex)=agents(activeIndex,productVectorIndex)-totalRequirements; %half step towards production (reserve the stock for production)
					%perform production
					productionMatrix(activeIndex,:)=agentProduction;
					consumptionMatrix(activeIndex,:)=totalRequirements;
				end
			else
				%consumer agent
				if (iterations>interventionPeriod(1))&&(iterations<interventionPeriod(2)),
					%intervention on consumer side
					%do nothing
				else
					%perform normal consumption
					
					%work out consumption
					% the minimum plan is going to be minimum plan allowed with
					% the current money and available products. it can be compared 
					% to the minimum consumption amount to be alive.
					[minimumPlan minimumProducts] = viableMinimumPlan(activeIndex,agents,prices,consumables,consumptionPatternIndex,inputMatrix,outputMatrix,productVectorIndex,producerSkills);
				
					if ~isempty(minimumPlan),
						%work out the cost of the minimum plan
						consumptionPattern=minimumPlan;
						priceC=prices(minimumProducts)*consumptionPattern';
						% a consumer agent consumes only the minimum plan if its current money reserves 
						% (savings) do not allow it to survive for more than 5 iterations
						survivalAmount=iterationsForSurvival*priceC*minConsumptionC;
						agentMoney=activeAgent(moneyIndex);
						% work out how much money the agent can spend in luxury products
						% on top of the survival consumption
						if agentMoney>survivalAmount,
							excessMoney=agentMoney-survivalAmount;
							agentsProductionBuffer(activeIndex,1)=1;
						else
							excessMoney=0;
						end
						% account for money making (is the agent selling all the labour and therefore consuming luxury?)
						% this was going to be used to introduce new consumer on the basis of them all selling labour and 
						% not starving - this is not being used at the moment
						excessMoneyBuffer(consumerCounter)=excessMoney;
						consumerCounter=consumerCounter+1;
						excessConsumptionC=excessMoney/priceC;

						%initialise a few vectors
						agentProduction=0*prices;
						agentConsumption=0*prices;
						agentMinConsumption=0*prices;
						agentLuxuryConsumption=0*prices;
						% work out the agent's consumption acounting for 
						% minimum plan plus luxury consumption
						% work out minimum plan and add to consumption
						agentMinConsumption(minimumProducts)=minConsumptionC*consumptionPattern;
						% work out global stock in market (product for sale - not including capital)
						[sellingStock capitalStock availableProducts]=workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills);
						% work out the luxury using the entire pattern not just the minimum plan
						consumptionPattern=activeAgent(consumptionPatternIndex);
						% spend in luxury products a random amount of the excess money
						luxuryExpenses=rand(1)*excessMoney;
						% work out luxury plan consumption
						[luxuryPlan luxuryProducts]=viableExcessConsumption(sellingStock-agentMinConsumption,prices,consumptionPattern,consumables,luxuryExpenses);
						agentLuxuryConsumption(luxuryProducts)=luxuryPlan;
						% final consumption (minimum plan plus luxury consumption)
						agentConsumption=agentMinConsumption+agentLuxuryConsumption;
						% update production vector (waste generation is proportional to consumption)
						consumptionWaste=agentConsumption(consumables)*consumptionWasteGeneration';
						agentProduction([relativePositionLabour relativePositionWasteProduct])=[0 consumptionWaste];
						%check for available products vs requirements and enough money
						requirements=agentConsumption;
						requirementsCost=prices*requirements';

						% % warning: WATCH OUT FOR ERROR THAT MAY ORIGINATE FROM COMMENTING THE FOLLOWING LINE
						% [sellingStock capitalStock availableProducts]=workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills);
					
						%if enough stock and money then consume
						if (sum((sellingStock-requirements)<0)==0)&&(agentMoney>requirementsCost),
							%go ahead with consumption plan
							activeConsumption=1;
							agentsProductionBuffer(activeIndex,1)=activeConsumption;
						else
							% consumer agent does nothing (starving)
							activeConsumption=0;
							agentsProductionBuffer(activeIndex,1)=activeConsumption;
						end
					else
						% if there is no minimum plan the
						% consumer agent does nothing (starving)
						activeConsumption=0;
						agentsProductionBuffer(activeIndex,1)=activeConsumption;
					end
					if activeConsumption,
						%actual exchange
						agents=exchangeProducts(activeIndex,agents,moneyIndex,productVectorIndex,producerSkills,requirements,prices,inputMatrix,outputMatrix);
						%reserve the consumption of required products
						agents(activeIndex,productVectorIndex)=agents(activeIndex,productVectorIndex)-requirements; %half step towards production (reserve the stock for production)
						%perform consumption
						productionMatrix(activeIndex,:)=agentProduction;
						consumptionMatrix(activeIndex,:)=requirements;
					else
						% % do nothing (but print message!)
						% % consumers that are starving (not consuming)
						% % will be selected for removal below when removing agents
						% %*********************************
						% % WRITE TO LOG FILE
						% %*********************************
						% if writeToLog,
						% 	printf('[%d] There has been no consumption by agent A%d \n',iterations,activeAgent(1));
						% 	fflush(stdout);
						% 	logFileID=fopen(logFileName,'a');
						% 	fprintf(logFileID,'[%d] There has been no consumption by agent A%d \n',iterations,activeAgent(1));
						% 	fclose(logFileID);
						% end
					end
				end%intervention period
			end
		end% agents within the window
		%update agents posessions
		agents(:,productVectorIndex)=agents(:,productVectorIndex)+productionMatrix;

		%*********************************
		% UPDATE PRICES
		%*********************************
		% work out the current production stock and demand
		[sellingStock capitalStock availableProducts]=workOutSellingCapitalStock(agents,inputMatrix,outputMatrix,productVectorIndex,producerSkills);
		% the following lines fix a problem with the target stock of the system
		% at the time of updating the prices. if there is any product
		% for which the target stock is zero, it means that its production 
		% should be zero too as there are no active producers creating it.
		% There should not be such a problem if initialStock of the target 
		% product is removed from the system when eliminating an agent.
		% Thus the if sentence will never be true and can be removed.
		priceBalanceVar=productionStock+targetStock;
		if sum(targetStock==0)>0,
			priceBalanceVar(find(targetStock==0))=0;
		end
		% actual update of the price vector
		prices=workOutPricesRational(sellingStock,priceBalanceVar,prices);
		% set the prices of labour, money, waste and free good
		prices(relativePositionLabour)=1; % do not change labour
		prices(relativePositionMoney)=1; %it should not be changed by the price function but just in case
		prices(relativePositionWasteProduct)=0; % just in case it might be changed
		prices(relativePositionFreeGood)=0; %update the price of free good to avoid it to be infinity and hence drive the rest to infinity
		
		% update production buffer and stock
		productionBuffer(2:bufferSize,:)=productionBuffer(1:bufferSize-1,:);
		productionBuffer(1,:)=sellingStock-targetStock;
		productionStock=mean(productionBuffer,1);
		
		% update profits
		profitVector=(prices*outputMatrix)./(prices*inputMatrix);
		profitBuffer(2:profitBufferSize,:)=profitBuffer(1:profitBufferSize-1,:);
		profitBuffer(1,:)=profitVector;
		meanProfits=mean(profitBuffer,1);
		makingLosses=find(sum((profitBuffer<1),1)==profitBufferSize); %technologies that are sistematically making losses for a number of iterations
		
		% compute the number of producers using each of the technologies
		producerConcentrations=sum(agents(:,producerSkills));
		producerConcentrationsBuffer(2:producerConcentrationsBufferSize,:)=producerConcentrationsBuffer(1:producerConcentrationsBufferSize-1,:);
		producerConcentrationsBuffer(1,:)=producerConcentrations;
		
		%*********************************
		% STORE DATA FOR VISUALISATION
		%*********************************
		consumersMoney=sum(agents(consumerAgents,moneyIndex));
		producersMoney=sum(agents(producerAgents,moneyIndex));
		myProfit=ones(1,6);
		myProfit(1:length(profitVector))=profitVector;
		producerConsumerBalance=[length(producerAgents) length(consumerAgents)];
		%actual storying
		products2Store=sellingStock;
		products2Store(3)=products2Store(3)+dumpField; %add the dumpField variable to account for all waste generated
		myRecords(storingCounter) = storeThings(productNames,prices,products2Store,technologyNames,profitVector,producerConcentrations,producerConsumerBalance);
		% myRecords(storingCounter) = storeThings(productNames,prices,sellingStock,technologyNames,profitVector,producerConcentrations,producerConsumerBalance);
		storingCounter=storingCounter+1;
	end%for(windows) END OF WINDOW
	
	%*********************************
	%*********************************
	% SYSTEM DYNAMICS
	%*********************************
	%*********************************

	%*********************************
	% 	REMOVE TECHNOLOGIES
	%*********************************
	% remove technologies not being used
	notBeingUsed=find(sum(producerConcentrationsBuffer)==0);
	if ~isempty(notBeingUsed),
		notBeingUsed=sort(notBeingUsed,'descend'); %sort in descending order to avoid accessing indexes that have just been removed
		for techCounter=1:length(notBeingUsed),
			targetTechnology=notBeingUsed(randi(length(notBeingUsed)));
			targetTechnology=notBeingUsed(techCounter);
			targetProduct=find(outputMatrix(:,targetTechnology)==1); %just for printing out purposes (product name)		
			%*********************************
			% WRITE TO LOG FILE
			%*********************************
			if writeToLog,
				printf('[%d] Trying to remove technology %s - product %s \n',iterations,technologyNames(targetTechnology,:),productNames(targetProduct,:));
				fflush(stdout);
				logFileID=fopen(logFileName,'a');
				fprintf(logFileID,'[%d] Trying to remove technology %s - product %s \n',iterations,technologyNames(targetTechnology,:),productNames(targetProduct,:));
				fclose(logFileID);
			end
			%remove technology and associated production if a product is not being used in 5 iterations and there are no dependencies with other technologies/products
			[removalOutcome inputMatrix outputMatrix inputMatrixWaste outputMatrixWaste agents prices manufactured consumables numberOfProducts numberOfTechnologies productVectorIndex producerSkillsRelative producerSkills producerIntroductionMatrix sellingStock targetStock productionBuffer productionStock profitVector profitBuffer meanProfits productNames technologyNames producerConcentrationsBuffer consumptionPatternIndex consumptionWasteGeneration] = removeTechnology(targetTechnology,inputMatrix,outputMatrix,inputMatrixWaste,outputMatrixWaste,agents,prices,manufactured,consumables,producerSkills,productVectorIndex,producerIntroductionMatrix,targetStock,productionBuffer,productionStock,profitVector,profitBuffer,meanProfits,productNames,technologyNames,producerConcentrationsBuffer,sellingStock,consumptionPatternIndex,consumptionWasteGeneration);
			if removalOutcome,
				%*********************************
				% WRITE TO LOG FILE
				%*********************************
				if writeToLog,
					printf('[%d] Technology removed \n',iterations);
					fflush(stdout);
					logFileID=fopen(logFileName,'a');
					fprintf(logFileID,'[%d] Technology removed \n',iterations);
					fclose(logFileID);
					printMatrices (logFileName,inputMatrix,outputMatrix,manufactured,consumables,productNames,technologyNames);
				end
			end
		end
	end%technologies not being used -> remove technology and product
	%*********************************
	% 	END OF REMOVE TECHNOLOGIES
	%*********************************
	
	%*********************************
	% 	INTRODUCE NEW TECHNOLOGIES
	%*********************************

	newTechProbability=0.005;
	newConsumableProbability=0.001;
	randomDraw=rand(1,2);

	if randomDraw(1)<newTechProbability,
		[numberOfProducts numberOfTechnologies]=size(inputMatrix);
		%introduce (a pair of) technologies
		[lowestProfit lowestProfitTech]=min(profitVector); %select the technology with the lowest profit
		[largestProfit largestProfitTech]=max(profitVector); %select the technology with the largest profit (not used)
		randChoiceTech=randi(numberOfTechnologies); %random choice of target technology
		biasTechChoice=[ones(1,5)*lowestProfitTech randChoiceTech]; % five to one more chances of choosing the lowest profit

		targetTechnology=biasTechChoice(randi(length(biasTechChoice))); % select one from the previous vector
		targetProduct=find(outputMatrix(:,targetTechnology)==1); %just for printing out purposes (product name)
		targetProfit=profitVector(targetTechnology)+0.05; %increase the profit a bit (innovation)
		[inputMatrix outputMatrix inputMatrixWaste outputMatrixWaste agents prices manufactured consumables numberOfProducts numberOfTechnologies productVectorIndex producerSkillsRelative producerSkills numberOfAgents producerIntroductionMatrix availableProducts targetStock productionBuffer productionStock profitVector profitBuffer meanProfits productNameCounter technologyNameCounter productNames technologyNames producerConcentrationsBuffer consumptionPatternRelativeIndex consumptionPatternIndex agentsProductionBuffer] = introduceNewTechnologies(targetTechnology,targetProfit,inputMatrix,outputMatrix,inputMatrixWaste,outputMatrixWaste,prices,manufactured,consumables,agents,producerIntroductionMatrix,targetStock,productionBuffer,profitBuffer,agentGlobalCounter,agentsProductionBuffer,productNameCounter,technologyNameCounter,productNames,technologyNames,producerConcentrationsBuffer,consumerAgents,consumptionPatternIndex);
		%*********************************
		% WRITE TO LOG FILE
		%*********************************
		if writeToLog,
			printf('[%d] Introducing new technologies %s and %s in the system - products %s and %s \n',iterations,technologyNames(numberOfTechnologies-1,:),technologyNames(numberOfTechnologies,:),productNames(numberOfProducts,:),productNames(targetProduct,:));
			fflush(stdout);
			logFileID=fopen(logFileName,'a');
			fprintf(logFileID,'[%d] Introducing new technologies %s and %s in the system - products %s and %s \n',iterations,technologyNames(numberOfTechnologies-1,:),technologyNames(numberOfTechnologies,:),productNames(numberOfProducts,:),productNames(targetProduct,:));
			fclose(logFileID);
			printMatrices (logFileName,inputMatrix,outputMatrix,manufactured,consumables,productNames,technologyNames);
		end
	end
	if randomDraw(2)<newConsumableProbability,
		%introduce consumable and its technology
		[inputMatrix outputMatrix inputMatrixWaste outputMatrixWaste agents prices manufactured consumables numberOfProducts numberOfTechnologies productVectorIndex producerSkillsRelative producerSkills numberOfAgents producerIntroductionMatrix availableProducts targetStock productionBuffer productionStock profitVector profitBuffer meanProfits productNameCounter technologyNameCounter productNames technologyNames producerConcentrationsBuffer consumptionPatternRelativeIndex consumptionPatternIndex agentsProductionBuffer consumptionWasteGeneration] = introduceNewConsumable(inputMatrix,outputMatrix,inputMatrixWaste,outputMatrixWaste,prices,manufactured,consumables,agents,producerIntroductionMatrix,targetStock,productionBuffer,profitBuffer,agentGlobalCounter,agentsProductionBuffer,productNameCounter,technologyNameCounter,productNames,technologyNames,producerConcentrationsBuffer,consumptionWasteGeneration);
		%*********************************
		% WRITE TO LOG FILE
		%*********************************
		if writeToLog,
			printf('[%d] Introducing a new consumable product %s and its technology %s in the system \n',iterations,productNames(numberOfProducts,:),technologyNames(numberOfTechnologies,:));
			fflush(stdout);
			logFileID=fopen(logFileName,'a');
			fprintf(logFileID,'[%d] Introducing a new consumable product %s and its technology %s in the system \n',iterations,productNames(numberOfProducts,:),technologyNames(numberOfTechnologies,:));
			fclose(logFileID);
			printMatrices (logFileName,inputMatrix,outputMatrix,manufactured,consumables,productNames,technologyNames);
		end
	end

	%*********************************
	% 	END OF INTRODUCE NEW TECHNOLOGIES
	%*********************************
	
	%*********************************
	% 	INTRODUCE AND REMOVE AGENTS
	%*********************************
	% stochastic rules for varying the number of agents
	% consider making changes in the number of agents if 
	% a random number is within certain thresholds
	%
	% so far, there is a 25% chance of introducing/removing producers
	% per iteration distributed as 40% for introduction, 40% for 
	% removal and 20% for recovering technology
	%
	% there is also a 2% (not related to the 25% of above) 
	% chance of introducing a new consumer agent
	% per iteration (there will be a single type of change per iteration)
	thresholdForChanges=0.25;
	randomDraw=rand(1);
	if randomDraw<thresholdForChanges*0.3,
		%*********************************
		% 	INTRODUCE PRODUCER AGENT
		%*********************************
		%in this case a new producer is going to be introduced in the system
		%if the average (in 5 iterations) profit is larger than a given threshold
		profitThreshold=1.0;
		if sum(meanProfits>profitThreshold)>0,
			if rand(1)<0.1, %10 out of 100
				%choose any agent rather than always the most profitable
				agentType=randi(length(meanProfits));
			else %90 out of 100
				%choose the most profitable technology
				[voidVar agentType]=max(meanProfits);
			end
			targetProduct=find(outputMatrix(:,agentType)==1); %just for printing out purposes (product name)
			%introduce a producer agent with most profitable technology
			[agents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock agentsProductionBuffer] = introduceNewAgent(agentType,producerIntroductionMatrix,agentGlobalCounter,agents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer);
			%*********************************
				% WRITE TO LOG FILE
				%*********************************
				if writeToLog,
				printf('[%d] Introducing a producer with technology %s - product %s \n',iterations,technologyNames(agentType,:),productNames(targetProduct,:));
				fflush(stdout);
				logFileID=fopen(logFileName,'a');
				fprintf(logFileID,'[%d] Introducing a producer with technology %s - product %s \n',iterations,technologyNames(agentType,:),productNames(targetProduct,:));
				fclose(logFileID);
			end
		end
	elseif randomDraw<thresholdForChanges*0.8,
		%*********************************
		% 	REMOVE AGENT
		%*********************************
		%in this case an agent either producer or consumer is going to be removed from the system
		%if there is any that has not been producing for some iterations (typically 5)
		if sum(sum(agentsProductionBuffer,2)==0)>0,
			agentsNotProducing=find(sum(agentsProductionBuffer,2)==0);
			for outOfBusinessCounter=1:length(agentsNotProducing),
				% the following lines are in separate if sentences to allow 
				% different things to happen to consumers and producers when 
				% they are not productive (so far there is no difference)
				if producerCheck(agents(agentsNotProducing(outOfBusinessCounter),:),producerSkills),
					% producer agent - add to pool of nominated agents
					poolOfNominatedAgents(length(poolOfNominatedAgents)+1)=agentsNotProducing(outOfBusinessCounter);
					targetAgent=agents(agentsNotProducing(outOfBusinessCounter),:);
					targetTechnology=find(targetAgent(producerSkills)==1); %just for printing out purposes (technology name)
					targetProduct=find(outputMatrix(:,targetTechnology)==1); %just for printing out purposes (product name)
					%*********************************
					% WRITE TO LOG FILE
					%*********************************
					if writeToLog,
						printf('[%d] Adding a producer of product %s to the pool of agents for removal - technology %s \n',iterations,productNames(targetProduct,:),technologyNames(targetTechnology,:));
						fflush(stdout);
						logFileID=fopen(logFileName,'a');
						fprintf(logFileID,'[%d] Adding a producer of product %s to the pool of agents for removal - technology %s \n',iterations,productNames(targetProduct,:),technologyNames(targetTechnology,:));
						fclose(logFileID);
					end
				else
					% consumer agent - add to pool of nominated agents
					poolOfNominatedAgents(length(poolOfNominatedAgents)+1)=agentsNotProducing(outOfBusinessCounter);
					%*********************************
					% WRITE TO LOG FILE
					%*********************************
					if writeToLog,
						printf('[%d] Adding a consumer to the pool of agents for removal\n',iterations);
						fflush(stdout);
						logFileID=fopen(logFileName,'a');
						fprintf(logFileID,'[%d] Adding a consumer to the pool of agents for removal\n',iterations);
						fclose(logFileID);
					end
				end
				if ~isempty(poolOfNominatedAgents),
					% % choose one agent from the pool (this is the one to be removed)
					% nominatedAgents=poolOfNominatedAgents(randi(length(poolOfNominatedAgents)));
					% work out a percentage of the total population that can be removed
					maxRemoval=round(numberOfAgents*removalPercentage);
					if maxRemoval>length(poolOfNominatedAgents),
						% remove all agent in the pool of nominated
						nominatedAgents=poolOfNominatedAgents;
					else
						for removalCounter=1:maxRemoval,
							randomDraw=randi(length(poolOfNominatedAgents));
							nominatedAgents(removalCounter)=poolOfNominatedAgents(randomDraw);
							poolOfNominatedAgents(randomDraw)=[];%avoid choosing the same agent twice
						end
					end
					nominatedAgents=sort(nominatedAgents,'descend');
				end
			end
		end
		% if there is any agent to be removed (not producing/consuming for some iterations) -> remove from system
		if ~isempty(nominatedAgents),
			for removalCounter=1:length(nominatedAgents),
				targetAgent=agents(nominatedAgents(removalCounter),:); %just for printing out purposes (technology name)
				targetTechnology=find(targetAgent(producerSkills)==1); %just for printing out purposes (technology name)
				%check for consumer or producer
				if ~isempty(targetTechnology), 
					%then it is a producer agent
					targetProduct=find(outputMatrix(:,targetTechnology)==1); %just for printing out purposes (product name)
					%*********************************
					% WRITE TO LOG FILE
					%*********************************
					if writeToLog,
						printf('[%d] Removing a single agent with technology %s - product %s \n',iterations,technologyNames(targetTechnology,:),productNames(targetProduct,:));
						fflush(stdout);
						logFileID=fopen(logFileName,'a');
						fprintf(logFileID,'[%d] Removing a single agent with technology %s - product %s \n',iterations,technologyNames(targetTechnology,:),productNames(targetProduct,:));
						fclose(logFileID);
					end
				else
					%the agent is a consumer
					%*********************************
					% WRITE TO LOG FILE
					%*********************************
					if writeToLog,
						printf('[%d] Removing a consumer agent A%d \n',iterations,targetAgent(1));
						fflush(stdout);
						logFileID=fopen(logFileName,'a');
						fprintf(logFileID,'[%d] Removing a consumer agent A%d \n',iterations,targetAgent(1));
						fclose(logFileID);
					end
				end							
				% actual removal of non producing agent (it has to be after printing out the action to access the agent's data)
				[agents numberOfAgents producerAgents consumerAgents targetStock agentsProductionBuffer dumpField] = removeAgent(nominatedAgents(removalCounter),agents,targetStock,producerSkills,productVectorIndex,inputMatrix,outputMatrix,agentsProductionBuffer,dumpField);
			end%for
		end%if
	elseif randomDraw<thresholdForChanges,
		%*********************************
		% 	INTRODUCE PRODUCER AND RECOVER TECHNOLOGY
		%*********************************
		%in this case a technology actually not in use but linked to other technologies or products is going to be recovered 
		% find out if there is any such technologies (not in use but linked to others)
		notBeingUsed=find(sum(producerConcentrationsBuffer)==0);	
		if ~isempty(notBeingUsed),
			%if there are more than one -> choose one at random
			agentType=notBeingUsed(randi(length(notBeingUsed)));
			targetProduct=find(outputMatrix(:,agentType)==1); %just for printing out purposes (product name)
			
			%introduce new agent
			[agents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock agentsProductionBuffer] = introduceNewAgent(agentType,producerIntroductionMatrix,agentGlobalCounter,agents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer);
			%*********************************
			% WRITE TO LOG FILE
			%*********************************
			if writeToLog,
				printf('[%d] Recovering technology %s - new producer of %s \n',iterations, technologyNames(agentType,:),productNames(targetProduct,:));
				fflush(stdout);
				logFileID=fopen(logFileName,'a');
				fprintf(logFileID,'[%d] Recovering technology %s - new producer of %s \n',iterations, technologyNames(agentType,:),productNames(targetProduct,:));
				fclose(logFileID);
			end
		end
	elseif randomDraw<thresholdForChanges+0.02,
		%*********************************
		% 	INTRODUCE CONSUMER AGENT
		%*********************************
		%in this case a new consumer agent will be introduced in the system
		% create template for consumer agents using the mean pattern of consumption
		consumerTemplate=zeros(1,length(agents(1,:)));
		meanPattern=mean(agents(consumerAgents,consumptionPatternIndex));
		initialMoney=10;
		initialStock=10;
		consumerTemplate(labourPosition)=initialStock;
		consumerTemplate(moneyIndex)=initialMoney;
		consumerTemplate(wasteProductPosition)=eps;
		consumerTemplate(freeGoodPosition)=inf;
		consumerTemplate(consumptionPatternIndex)=meanPattern;
		consumerIntroductionMatrix=[consumerTemplate];
		agentType=1; %there is only one type of consumer
		%introduce new consumer agent
		[agents numberOfAgents producerAgents consumerAgents agentGlobalCounter targetStock agentsProductionBuffer] = introduceNewAgent(agentType,consumerIntroductionMatrix,agentGlobalCounter,agents,targetStock,producerSkills,productVectorIndex,agentsProductionBuffer);
		%*********************************
		% WRITE TO LOG FILE
		%*********************************
		if writeToLog,
			printf('[%d] New consumer agent\n',iterations);
			fflush(stdout);
			logFileID=fopen(logFileName,'a');
			fprintf(logFileID,'[%d] New consumer agent\n',iterations);
			fclose(logFileID);
		end
	end	
	%*********************************
	% 	END OF INTRODUCE AND REMOVE AGENTS
	%*********************************
	%*********************************
	% THIS COMPLETES AN ITERATION
	%*********************************
end %iterations

%*********************************
% VISUALISE DATA
%*********************************
% %after the execution of the main loop plot the results
% if ~writeToLog,
% 	printf('\b');
% 	printf('Plotting the results\n');
% end
%
% % after the simulation have a look at the productNameCounter and technologyNameCounter variables to plot them all products and technologies in the following manner
%
% % routine to plot them all products
%
% for counter = 1 : technologyNameCounter,
% 	technologies2Plot{counter}=['T' num2str(counter)];
% end
%
% for counter = 1 : productNameCounter,
% 	products2Plot{counter}=['P' num2str(counter)];
% end

% plotPrices(101,myRecords,products2Plot);
% plotAvailable(102,myRecords,products2Plot);
% plotProfits(103,myRecords,technologies2Plot);
% plotConcentrations(104,myRecords,technologies2Plot);
% plotProducerConsumerBalance(105,myRecords);
%
% storePrices('outputPrices.csv',myRecords,products2Plot);
% storeAvailable('outputAvailable.csv',myRecords,products2Plot);
% storeProfits('outputProfits.csv',myRecords,technologies2Plot);
% storeConcentrations('outputConcentrations.csv',myRecords,technologies2Plot);
% storeProducerConsumerBalance('outputProdConBalance.csv',myRecords);

%% manual introduction 
%plotPrices(101,myRecords,'P1','P2','P3','P4','P5','P6','P7','P8','P9','P10','P11','P12','P13','P14','P15','P16','P17','P18','P19','P20','P21','P22','P23','P24','P25','P26','P27','P28','P29','P30');
%plotAvailable(102,myRecords,'P1','P2','P3','P4','P5','P6','P7','P8','P9','P10','P11','P12','P13','P14','P15','P16','P17','P18','P19','P20','P21','P22','P23','P24','P25','P26','P27','P28','P29','P30');
%plotProfits(103,myRecords,'T1','T2','T3','T4','T5','T6','T7','T8','T9','T10','T11','T12','T13','T14','T15','T16','T17','T18','T19','T20','T21','T22','T23','T24','T25','T26','T27','T28','T29','T30','T31','T32','T33','T34','T35','T36','T37');
%plotConcentrations(104,myRecords,'T1','T2','T3','T4','T5','T6','T7','T8','T9','T10','T11','T12','T13','T14','T15','T16','T17','T18','T19','T20','T21','T22','T23','T24','T25','T26','T27','T28','T29','T30','T31','T32','T33','T34','T35','T36','T37');

%*********************************
% SAVE DATA
%*********************************

% save simulationData001.data myRecords products2Plot technologies2Plot
save simulationData001.data

% save('simulationData001.data')
% save -binary data myRecords



