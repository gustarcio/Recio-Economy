function [] = plotAll(workingFolderPath),
	% -- Function file: plotAll(workingFolderPath)
	%
	% Summary: plot the figures related to current 
	% experiment in in the folder description
	%
	% It makes use of several plot routines that can
	% be found in the working folder (e.g. plotPrices)
	%
	% example: plotAll('./') or plotAll('../../../evolvingEconomy_v10_github')
	
	load simulationData001.data;
	addpath(workingFolderPath);
	plotPrices(101,myRecords,'P5','P6','P7','P8')
	plotAvailable(102,myRecords,'P5','P6','P7','P8');
	plotProfits(103,myRecords,'T1','T2','T3','T4');
	plotConcentrations(104,myRecords,'T1','T2','T3','T4');
	rmpath(workingFolderPath);

	figure(101),
	grid on
	legend('P4','P5','P6','P7','location','northeast')
	axis([1 1000 0 3.25])
	figure(102),
	for counter=1:1000,
		labourLeft(counter)=myRecords(counter).availableProducts(1);
	end
	hold on
	plot(labourLeft,'k','linewidth',2)
	hold off
	grid on
	legend('P4','P5','P6','P7',"P2",'location','northeast')
	axis([1 1000 0 350])
	figure(103),
	grid on
	legend('T1','T2','T3','T4','location','northeast')
	axis([1 1000 0.7 1.55])
	figure(104),
	grid on
	legend('T1','T2','T3','T4','location','northeast')
	axis([1 1000 0 30])

	print(101,'results007.eps','-deps','-F:12','-color');
	print(102,'results008.eps','-deps','-F:12','-color');
	print(103,'results009.eps','-deps','-F:12','-color');
	print(104,'results010.eps','-deps','-F:12','-color');

	close all

end% plotAll()
