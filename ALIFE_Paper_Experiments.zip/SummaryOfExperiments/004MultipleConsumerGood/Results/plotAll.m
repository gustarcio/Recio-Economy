function [] = plotAll(workingFolderPath),
	% -- Function file: plotAll(workingFolderPath)
	%
	% Summary: plot the figures related to current 
	% experiment in in the folder description
	%
	% It makes use of several plot routines that can
	% be found in the working folder (e.g. plotPrices)
	%
	% example: plotAll('./') or plotAll('../../../evolvingEconomy_v10_github')
	
	load simulationData001.data;
	for counter=1:2000,
		prodP1available(counter)=myRecords(counter).availableProducts(1);	
		prodP3available(counter)=myRecords(counter).availableProducts(3);	
	end

	for counter=101:2000,
		prodP9price(counter-100)=myRecords(counter).prices(9);
		prodP9available(counter-100)=myRecords(counter).availableProducts(9);
		techT5profit(counter-100)=myRecords(counter).profitVector(5);
		techT5concentrations(counter-100)=myRecords(counter).producerConcentrations(5);
	end
	addpath(workingFolderPath);
	plotPrices(101,myRecords,'P5','P6','P7','P8')
	plotAvailable(102,myRecords,'P5','P6','P7','P8');
	plotProfits(103,myRecords,'T1','T2','T3','T4');
	plotConcentrations(104,myRecords,'T1','T2','T3','T4');
	rmpath(workingFolderPath);
	figure(101),
	hold on 
	plot([101:2000],prodP9price,'k','linewidth',2)
	hold off
	grid on
	legend('P4','P5','P6','P7',"P8",'location','northeast')
	axis([1 2000 0.5 3.5])
	figure(102),
	hold on
	plot([101:2000],prodP9available,'color',[0.4 0.4 0.4],'linewidth',2)
	plot(prodP1available,'color',[0 0 0],'linewidth',2)
	plot(prodP3available,'color',[0.3 0.0 0.0],'linewidth',2)
	hold off
	grid on
	legend('P4','P5','P6','P7','P8','P1','P3','location','northeast')
	axis([1 2000 0 800])
	figure(103),
	hold on
	plot([101:2000],techT5profit,'k','linewidth',2)
	hold off
	grid on
	axis([1 2000 0.5 3])
	legend('T1','T2','T3','T4','T5','location','northeast')
	figure(104),
	hold on
	plot([101:2000],techT5concentrations,'k','linewidth',2)
	hold off
	grid on
	axis([1 2000 0 30])
	legend('T1','T2','T3','T4','T5','location','northeast')

	figure(110),
	plot(monitoringConsumption(6,1,:),'color',[0 0 0.6],'linewidth',2)
	hold on
	plot([101:2000],monitoringConsumption(6,2,101:2000),'color',[0 0.2 0.2],'linewidth',2)
	hold off
	grid on
	axis([0 2000 0 5])
	legend('P7','P8','location','northeast')
	xlabel('Iterations')
	ylabel('Consumption per product')
	title('Consumer 6')

	figure(112),
	plot(monitoringConsumption(8,1,:),'color',[0 0 0.6],'linewidth',2)
	hold on
	plot([101:2000],monitoringConsumption(8,2,101:2000),'color',[0 0.2 0.2],'linewidth',2)
	hold off
	grid on
	axis([0 2000 0 5])
	legend('P7','P8','location','northeast')
	xlabel('Iterations')
	ylabel('Consumption per product')
	title('Consumer 8')

	print(101,'results101.eps','-deps','-F:12','-color');
	print(102,'results102.eps','-deps','-F:12','-color');
	print(103,'results103.eps','-deps','-F:12','-color');
	print(104,'results104.eps','-deps','-F:12','-color');
	print(110,'results110.eps','-deps','-F:12','-color');
	print(112,'results112.eps','-deps','-F:12','-color');

	close all

end% plotAll()
