This respository is aimed at replicating the experiments shown in the ALIFE paper "From Dynamics to Novelty".

Please feel free to navigate through all the folders and re-run any of the experiments following the instructions that can be found in the folder README.txt file.

To run an experiment you need to download the full package Recio_Economy.zip and modify the mainEconomy.m file according to the configuration parameters of the experiment you want to execute. Inside each folder there is a copy of this file for easy access with the required configuration. The original mainEconomy.m file in the package must be replaced by the experiment mainEconomy.m file to run a given experiment.

